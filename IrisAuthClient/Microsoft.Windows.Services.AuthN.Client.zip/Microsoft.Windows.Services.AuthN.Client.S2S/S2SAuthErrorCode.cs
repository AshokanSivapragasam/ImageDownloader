using System;
namespace Microsoft.Windows.Services.AuthN.Client.S2S
{
	public enum S2SAuthErrorCode
	{
		GetAccessTokenFailed,
		CannotFindCertificate
	}
}
