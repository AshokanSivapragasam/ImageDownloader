using System;
namespace Microsoft.Windows.Services.AuthN.Client
{
	public static class RpsAuthPolicy
	{
		public const string S2S24HoursMutualSsl = "S2S_24HOURS_MUTUALSSL";
	}
}
