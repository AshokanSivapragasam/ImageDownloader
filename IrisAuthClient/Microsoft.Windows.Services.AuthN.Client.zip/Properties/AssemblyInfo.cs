using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyVersion("9.0.0.0")]
[assembly: CLSCompliant(false)]
[assembly: SuppressMessage("Microsoft.AsyncExtensionUsage", "AC1000:PreserveAsyncContextualRule", Scope = "member", Target = "Microsoft.Windows.Services.Common.S2SAuth.Client.S2SAuthClient+<GetAccessTokenAsync>d__a.#MoveNext()")]
[assembly: SuppressMessage("Microsoft.AsyncExtensionUsage", "AC1000:PreserveAsyncContextualRule", Scope = "member", Target = "Microsoft.Windows.Services.Common.S2SAuth.Client.S2SAuthClient+<GetAccessTokenAsync>d__0.#MoveNext()")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("Copyright © 2015 Microsoft Corporation.  All rights reserved.")]
[assembly: AssemblyFileVersion("9.0.15257.1")]
[assembly: AssemblyProduct("Universal Store (MembershipAuthN) (Main) Retail")]
[assembly: AssemblyTitle("Microsoft.Windows.Services.AuthN.Client")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: ComVisible(false)]
