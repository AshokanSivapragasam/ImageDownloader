/*Azure bulksend*/

;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select (

(select
case when sum(case when rq2.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'Bulksendsuccess' and rq2.isfailedstate = 0 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 10 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end

+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'EiReceiveSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more requests are waiting to upload the data file to sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'FileUploadSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more requests are waiting for Salesforce to complete its part for 2+ hours<br/>This implies that requests are in ProgramPending state in Salesforce<br/>' else '' end

from dbo.requestqueue rq1 with (nolock)
full outer join dbo.requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
where (convert(date, rq1.createddatetime) >= convert(date, getdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getdate()-1))
and (rq1.requesttype = 'InterchangeFileRequest' and rq2.requesttype = 'InterchangeFileRequest')
and rq2.requestid not in (
select distinct emailinterchangeid from transactionallog with (nolock)
where convert(date, createddatetime) >= convert(date, getdate()-1)
and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%')
)
+
(select 
case when count(distinct emailinterchangeid) > 0 then 'Just for information. '+convert(nvarchar(max), count(distinct emailinterchangeid))+' requests failed by ''ProgramPending'' or ''ErrorTasks'' state. This is a failure at Salesforce.<br/>' else '' end
from transactionallog with (nolock)
where convert(date, createddatetime) >= convert(date, getdate()-1)
and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%'
)
)

/*Azure pl|sp|st*/


select 
case when (
--# of requests in archive in last 24 hours [normal| no requests]
case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
--# of requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
--# of failed requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
--# of requests in queue in progress for 3+ hours [normal| no requests]
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours' else '' end

) = '' then '<td class=''DiscrepanciesWithinThreshold''>Everything is fine</td><td class=''DiscrepanciesWithinThreshold''>No action required</td>' else (

'<td class=''DiscrepanciesAboveThreshold''>' --# of requests in archive in last 24 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
--# of requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
--# of failed requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
--# of requests in queue in progress for 3+ hours [normal| no requests]
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours<br/>' else '' end
+'</td><td class=''DiscrepanciesAboveThreshold''>'
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'Critical issue! This implies that Salesforce sftp server might have taken our service unresponsive<br/>Restart the InterchangeFileProcessor worker role instances of Azure cloud services<br/>' else '' end
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'Proactive measure! This could imply that Salesforce sftp server might have taken our service unresponsive<br/>Check the logs and restart the InterchangeFileProcessor worker role instances of Azure cloud services (<i>if and only if it is necessary</i>)<br/>' else '' end
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then 'Investigate on these failures, report it to concerned people<br/>' else '' end
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Too many requests are in queue waiting for Azure worker role<br/>Restart the InterchangeFileProcessor worker role instances of Azure cloud services<br/>' else '' end
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Low priority! This could imply that process completed; requests are waiting for getting archived<br/>Check the logs & azure table storage<br/>' else '' end
+'</td>'
) end
from requestqueue rq1 with (nolock)
full outer join requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
where (convert(date, rq1.createddatetime) >= convert(date, getdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getdate()-1))
and (rq1.requesttype in ('PromotionalListData', 'SuppressionPromotionalData', 'SuppressionTransactionalData') or rq2.requesttype in ('PromotionalListData', 'SuppressionPromotionalData', 'SuppressionTransactionalData'))
and rq2.requestid not in (select distinct EmailInterchangeId from transactionallog with (nolock)
where EventId=201130011 and MessageString like '%does not have access to ClientID%')


/*Azure FileTrigger*/

select 
case when (
--# of requests in archive in last 24 hours [normal| no requests]
case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
--# of requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
--# of failed requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Azure File Notifier Service is unresponsive<br/>' else '' end
--# of requests in queue in progress for 3+ hours [normal| no requests]
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours' else '' end

) = '' then '<td class=''DiscrepanciesWithinThreshold''>Everything is fine</td><td class=''DiscrepanciesWithinThreshold''>No action required</td>' else (
'<td class=''DiscrepanciesAboveThreshold''>' --# of requests in archive in last 24 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
--# of requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
--# of failed requests in archive in last 2 hours [normal| no requests]
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
--# of requests in queue in progress for 3+ hours [normal| no requests]
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours<br/>' else '' end
+'</td><td class=''DiscrepanciesAboveThreshold''>'
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'Critical issue! This implies that Salesforce sftp server might have taken our service unresponsive<br/>Restart Azure File Notifier Service<br/>' else '' end
+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'Proactive measure! This could imply that Azure File Notifier Service is unresponsive<br/>Check the logs and restart Azure File Notifier Service (<i>if and only if it is necessary</i>)<br/>' else '' end
+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then 'Investigate on these failures, resubmit the requests using resubmit tools available and report it to concerned people (if absolutely necessary)<br/>' else '' end
+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Too many requests are in queue waiting for Azure File Notifier Service<br/>Restart Azure File Notifier Service<br/>' else '' end
+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Low priority! This could imply that process completed; requests are waiting for getting archived<br/>Check the logs & azure table storage<br/>' else '' end
+'</td>'
) end
from requestqueue rq1 with (nolock)
full outer join requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
where (convert(date, rq1.createddatetime) >= convert(date, getdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getdate()-1))
and (rq1.requesttype = 'FileTriggerData' or rq2.requesttype = 'FileTriggerData')
and rq2.requestid not in (select distinct EmailInterchangeId from transactionallog with (nolock)
where EventId=201130011 and MessageString like '%does not have access to ClientID%')