DECLARE @emailMessage NVARCHAR(MAX) = '
				<table style=''font-family: Segoe UI''>
					<tr class=''header''>
						<td colspan=''4'' align=''center''>Azure Health Reports</td>
					</tr>
					<tr class=''header''>
						<td align=''center''>Scenario</td>
						<td align=''center''>category</td>
						<td align=''center''>Notes</td>
						<td align=''center''>Action</td>
					</tr>
					<tr>
						<td>#0</td>
						<td>TriggeredRequest (<i>aka Tbn</i>)</td>
						<td>[TriggeredRequestReport]</td>
					</tr>
					<tr>
						<td>#1</td>
						<td>InterchangeFileRequest (<i>aka Bulksend</i>)</td>
						<td>[InterchangeFileRequestReport]</td>
					</tr>
					<tr>
						<td>#2</td>
						<td>PromotionalList | SuppressionPromotional | SuppressionTransactional (<i>PL|SP|ST</i>)</td>
						<td>[PlSpStReport]</td>
					</tr>
					<tr>
						<td>#3</td>
						<td>FileTriggerData</td>
						<td>[FtdReport]</td>
					</tr>
					<tr>
						<td>#4</td>
						<td>EmailResponseData</td>
						<td class=''DiscrepanciesWithinThreshold''>EmailResponseData not implemented</td>
						<td class=''DiscrepanciesWithinThreshold''>EmailResponseData not implemented</td>
					</tr>
					<tr>
						<td>#5</td>
						<td>ReportExtractData</td>
						<td class=''DiscrepanciesWithinThreshold''>ReportExtractData not implemented</td>
						<td class=''DiscrepanciesWithinThreshold''>ReportExtractData not implemented</td>
					</tr>
				</table>
				<br/><br/>	
				[RequestCountBreakdown]
				<br/>

				<table style="font-family: Segoe UI;">
					<tbody>
						<tr class="header">
							<td align="center" colspan="4">Azure cloud services whereabouts</td>
						</tr>
						<tr class="header">
							<td align="center">SNo</td>
							<td align="center">Cloud service</td>
							<td align="center">Worker role</td>
							<td align="center">Responsibilities</td>
						</tr>
						<tr>
							<td>#1</td>
							<td rowspan="5">EmailInterchangeApi</td>
							<td>InterchangeAPI_IN_&lt;InstanceId&gt;</td>
							<td>Request logging & services for following types, Tbn | Bulksend | Msi Sub\ Unsub | Tracking feature | Afns</td>
						</tr>
						<tr>
							<td>#2</td>
							<td>InterchangeETProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing EmailReponseData request | Request logging for, ReportExtractData</td>
						</tr>
						<tr>
							<td>#3</td>
							<td>InterchangeFailover_IN_&lt;InstanceId&gt;</td>
							<td>Processing failed over Tbn & Bulksend requests</td>
						</tr>
						<tr>
							<td>#4</td>
							<td>InterchangeFileProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing following requests, Bulksend | PL | SP | ST | CMD</td>
						</tr>
						<tr>
							<td>#5</td>
							<td>InterchangeProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing following request, Tbn</td>
						</tr>
						<tr>
							<td>#6</td>
							<td rowspan="5">EmailInterchangeApi-Prod2</td>
							<td>InterchangeAPI_IN_&lt;InstanceId&gt;</td>
							<td>Request logging & services for following types, Tbn | Bulksend | Msi Sub\ Unsub | Tracking feature | Afns</td>
						</tr>
						<tr>
							<td>#7</td>
							<td>InterchangeETProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing EmailReponseData request | Request logging for, ReportExtractData</td>
						</tr>
						<tr>
							<td>#8</td>
							<td>InterchangeFailover_IN_&lt;InstanceId&gt;</td>
							<td>Processing failed over Tbn & Bulksend requests</td>
						</tr>
						<tr>
							<td>#9</td>
							<td>InterchangeFileProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing following requests, Bulksend | PL | SP | ST | CMD</td>
						</tr>
						<tr>
							<td>#10</td>
							<td>InterchangeProcessor_IN_&lt;InstanceId&gt;</td>
							<td>Processing following request, Tbn</td>
						</tr>
					</tbody>
				</table>
				<br/>
				';

				declare @emailBodyRequestBreakdown nvarchar(max) = '';
create table #temptable (tdc001 date , tdc002 varchar(100) , tdc003 varchar(100) , tdc004 int )

insert into #temptable
select
convert(date, createddatetime) as tdc, requesttype as tdc, 
case when isprocessing = 0 and isfailedstate = 0 then 'Waiting'
when isprocessing = 1 and isfailedstate = 0 then 'InProgress' else 'Unknown' end as tdc
, count(distinct requestid) as tdc
--select * 
from dbo.requestqueue with (nolock)
where convert(date, createddatetime) >= convert(date, getutcdate()-1)
and isfailedstate <> 2
group by convert(date, createddatetime), requesttype, 
case when isprocessing = 0 and isfailedstate = 0 then 'Waiting'
when isprocessing = 1 and isfailedstate = 0 then 'InProgress' else 'Unknown' end
order by convert(date, createddatetime) desc, requesttype desc

;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
insert into #temptable
select
convert(date, createddatetime) as tdc
, requesttype as tdc
, case when isfailedstate in (0, 1) then 'Completed' else 'Failed' end as tdc
, count(distinct requestid) as tdc
--select * 
from dbo.requestarchive with (nolock)
where convert(date, createddatetime) >= convert(date, getutcdate()-1)

and requestid not in (select requestid from requestarchive with (nolock) where
	(isfailedstate = 2 and object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)') in
	(select object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
	from dbo.requestarchive with (nolock)
	where convert(date, createddatetime) >= convert(date, getdate()-1)
	and requesttype in ('PromotionalListData','SuppressionPromotionalData','SuppressionTransactionalData','FileTriggerData')
	and isfailedstate <> 2)))

and requestid not in (select distinct emailinterchangeid from transactionallog with (nolock)
where eventid in (161004004, 161203005, 201130011,171008001,171002004,201005004) and (MessageString like '%Object reference%' or MessageString like '%Conversation has been invalidated%' or MessageString like '%does not have access to ClientID%'
or messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%'
or MessageString like '%Unable to find Triggered Send%'))
group by convert(date, createddatetime), requesttype, case when isfailedstate in (0, 1) then 'Completed' else 'Failed' end
order by convert(date, createddatetime) desc, requesttype desc


insert into #temptable
select
convert(date, ra.createddatetime) as tdc
, ra.requesttype as tdc
, case when tl.MessageString like '%Object reference%' then 'UserNullAttribute' 
		when tl.MessageString like '%Conversation has been invalidated%' then 'DuplicateConversationId'
		when tl.MessageString like '%Unable to find Triggered Send%' then 'InvalidTbnDefinition'
		when tl.MessageString like '%does not have access to ClientID%' then 'InvalidSubsidiaryAccountIdFixIt'
		when tl.messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%' then 'SfmcPendingOrErrorOnTasks'
		else 'UnidentifiedExceptions' end as tdc
, count(distinct ra.requestid) as tdc
--select * 
from dbo.requestarchive ra with (nolock)
inner join transactionallog tl with (nolock) on ra.requestid = tl.emailinterchangeid and (case when tl.MessageString like '%Object reference%' then 'UserNullAttribute' 
		when tl.MessageString like '%Conversation has been invalidated%' then 'DuplicateConversationId'
		when tl.MessageString like '%Unable to find Triggered Send%' then 'InvalidTbnDefinition'
		when tl.MessageString like '%does not have access to ClientID%' then 'InvalidSubsidiaryAccountIdFixIt'
		when tl.messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%' then 'SfmcPendingOrErrorOnTasks'
		else 'UnidentifiedExceptions' end <> 'UnidentifiedExceptions')
where convert(date, ra.createddatetime) >= convert(date, getutcdate()-1)
and tl.TransactionalLogId is not null
and isfailedstate in (1,2)
and tl.eventid in (161004004, 161203005, 201130011,171008001,171002004,201005004)
group by convert(date, ra.createddatetime), ra.requesttype, case when tl.MessageString like '%Object reference%' then 'UserNullAttribute' 
		when tl.MessageString like '%Conversation has been invalidated%' then 'DuplicateConversationId'
		when tl.MessageString like '%Unable to find Triggered Send%' then 'InvalidTbnDefinition'
		when tl.MessageString like '%does not have access to ClientID%' then 'InvalidSubsidiaryAccountIdFixIt'
		when tl.messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%' then 'SfmcPendingOrErrorOnTasks'
		else 'UnidentifiedExceptions' end
order by convert(date, ra.createddatetime) desc, ra.requesttype desc

;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
insert into #temptable
select
convert(date, createddatetime) as tdc
, requesttype as tdc
,'DuplicateFailedRequests' as tdc
, count(distinct requestid) as tdc
from dbo.requestarchive with (nolock)
where convert(date, createddatetime) >= convert(date, getdate()-1)
and requesttype in ('PromotionalListData','SuppressionPromotionalData','SuppressionTransactionalData','FileTriggerData')
and isfailedstate = 2
and object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)') in
	(select object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
	from dbo.requestarchive with (nolock)
	where convert(date, createddatetime) >= convert(date, getdate()-1)
	and requesttype in ('PromotionalListData','SuppressionPromotionalData','SuppressionTransactionalData','FileTriggerData')
	and isfailedstate <> 2)
group by convert(date, createddatetime), requesttype
order by convert(date, createddatetime) desc, requesttype desc

declare @date varchar(100), @requesttype varchar(100), @requeststatus varchar(100), @numberOfDateOccurrences int, @numberOfTypeOccurrencesForDate int, @sumOfRequestsFallOnCategory int
declare @printdate nvarchar(100), @printrequesttype nvarchar(100), @printrequeststatus nvarchar(100), @breakdownColorcode nvarchar(100)

DECLARE date_cursor CURSOR FOR   
select distinct tdc001 from #temptable
order by tdc001 desc

DECLARE requesttype_cursor CURSOR FOR   
select distinct tdc002 from #temptable
order by tdc002 desc

DECLARE requeststatus_cursor CURSOR FOR   
select distinct tdc003 from #temptable
order by tdc003 desc

OPEN date_cursor

FETCH NEXT FROM date_cursor   
INTO @date

WHILE @@FETCH_STATUS = 0  
begin

	set @printdate = @date 
	select @numberOfDateOccurrences = count(1) from #temptable
	where tdc001 = @date

	OPEN requesttype_cursor
	FETCH NEXT FROM requesttype_cursor   
	INTO @requesttype
	WHILE @@FETCH_STATUS = 0  
	begin
		set @printrequesttype = @requesttype 
		select @numberOfTypeOccurrencesForDate = count(1) from #temptable
		where tdc001 = @date and tdc002 = @requesttype

		OPEN requeststatus_cursor
		FETCH NEXT FROM requeststatus_cursor   
		INTO @requeststatus
		WHILE @@FETCH_STATUS = 0  
		begin	
			set @printrequeststatus = @requeststatus
			select @sumOfRequestsFallOnCategory = sum(tdc004) from #temptable
			where tdc001 = @date and tdc002 = @requesttype and tdc003 = @requeststatus

			if(@sumOfRequestsFallOnCategory is not null)
			begin
				select @breakdownColorcode = case when @printrequeststatus in ('Completed', 'DuplicateConversationId', 'DuplicateFailedRequests') then 'DiscrepanciesWithinThreshold'
													  when @printrequeststatus in ('Inprogress', 'Waiting', 'Unknown', 'UserNullAttribute', 'InvalidTbnDefinition','InvalidSubsidiaryAccountIdFixIt', 'SfmcPendingOrErrorOnTasks') then 'DiscrepanciesWarningThreshold'
													  else 'DiscrepanciesAboveThreshold' end

				set @emailBodyRequestBreakdown = @emailBodyRequestBreakdown + ('<tr>'+ (case when @printdate <> '' then '<td align="center" style="white-space: nowrap;" rowspan="'+convert(nvarchar(max), @numberOfDateOccurrences)+'">'+@printdate + '</td>' else '' end) + (case when @printrequesttype <> '' then '<td align="center" style="white-space: nowrap;" rowspan="'+convert(nvarchar(max), @numberOfTypeOccurrencesForDate)+'">' + @printrequesttype + '</td>' else '' end) 
				+ '<td align="center" class="'+ @breakdownColorcode +'">' + @printrequeststatus + '</td><td align="center" style="white-space: nowrap;" class="'+ @breakdownColorcode +'">' + convert(nvarchar(max), @sumOfRequestsFallOnCategory) + '</td></tr>')
				set @printrequesttype = '';
				set @printdate = '';
			end
			
			FETCH NEXT FROM requeststatus_cursor
			INTO @requeststatus
		end
		CLOSE requeststatus_cursor

		FETCH NEXT FROM requesttype_cursor
		INTO @requesttype
	end
	CLOSE requesttype_cursor

FETCH NEXT FROM date_cursor
INTO @date
end

CLOSE date_cursor

DEALLOCATE date_cursor;  
DEALLOCATE requesttype_cursor;  
DEALLOCATE requeststatus_cursor;
drop table #temptable

SET @emailBodyRequestBreakdown = N'<table style=''font-family: Segoe UI''><tr class="header"><td align="center" colspan="4">On-premise Request Count Breakdown</td></tr>
				<tr class=''header''>
				<td align=''center''>RequestStartDatetime</td>
				<td align=''center''>RequestType</td>
				<td align=''center''>RequestStatus</td>
				<td align=''center''>Count</td>
			</tr>' + @emailBodyRequestBreakdown + '</table>'

SET @emailMessage = REPLACE(@emailMessage, '[RequestCountBreakdown]', @emailBodyRequestBreakdown)

--TriggeredRequestReport

				declare @tempTextField001 nvarchar(max),@tempTextField002 nvarchar(max),@tempTextField003 nvarchar(max),@tempTextField004 nvarchar(max);

				;WITH xmlnamespaces(DEFAULT 
				'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
				) 
				select @tempTextField001 = (select 
											case when sum(case when rq2.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'Bulksendsuccess' and rq2.isfailedstate = 0 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 10 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end

											+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'EiReceiveSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more requests are waiting to upload the data file to sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
											+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'FileUploadSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more requests are waiting for Salesforce to complete its part for 2+ hours<br/>This implies that requests are in ProgramPending state in Salesforce<br/>' else '' end

											from dbo.requestqueue rq1 with (nolock)
											full outer join dbo.requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
											where (convert(date, rq1.createddatetime) >= convert(date, getutcdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getutcdate()-1))
											and (rq1.requesttype = 'InterchangeFileRequest' and rq2.requesttype = 'InterchangeFileRequest')
											and rq2.requestid not in (
											select distinct emailinterchangeid from transactionallog with (nolock)
											where convert(date, createddatetime) >= convert(date, getutcdate()-1)
											and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%')
											)
											
				select @tempTextField002 = (select 
											case when count(distinct emailinterchangeid) > 0 then 'Just for information. '+convert(nvarchar(max), count(distinct emailinterchangeid))+' requests failed by ''ProgramPending'' or ''ErrorTasks'' state. This is a failure at Salesforce.<br/>' else '' end
											from transactionallog with (nolock)
											where convert(date, createddatetime) >= convert(date, getutcdate()-1)
											and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%'
											)

				select @tempTextField003 = (select 
											case when sum(case when rq2.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'Bulksendsuccess' and rq2.isfailedstate = 0 then 1 else 0 end) = 0 then 'Check request to see if there are any failures<br/>' else '' end
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 10 then 'Check logs for any issues; apply fix if it is resolvable.<br/>' else '' end

											+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'EiReceiveSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Restart InterchangeFileProcessor worker role instances by double-clicking the scenario.<br/>' else '' end
											+case when sum(case when rq1.object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)') = 'FileUploadSuccess' and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Restart InterchangeFileProcessor worker role instances by double-clicking if requests are in progress state for too long<br/>' else '' end

											from dbo.requestqueue rq1 with (nolock)
											full outer join dbo.requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
											where (convert(date, rq1.createddatetime) >= convert(date, getutcdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getutcdate()-1))
											and (rq1.requesttype = 'InterchangeFileRequest' and rq2.requesttype = 'InterchangeFileRequest')
											and rq2.requestid not in (
											select distinct emailinterchangeid from transactionallog with (nolock)
											where convert(date, createddatetime) >= convert(date, getutcdate()-1)
											and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%')
											)
											
				select @tempTextField004 = (select 
											case when count(distinct emailinterchangeid) > 0 then 'Salesforce or tenants is responsible for ''ProgramPending'' or ''ErrorTasks'' state. Ignore if it is too low.<br/>' else '' end
											from transactionallog with (nolock)
											where convert(date, createddatetime) >= convert(date, getutcdate()-1)
											and eventid in (171008001,171002004,201005004) and messagestring like '%Data import activity in Salesforce Marketing Cloud aka Exact Target is not completed or completed with warnings%'
											)

				select @emailMessage = REPLACE(@emailMessage, '<td>[InterchangeFileRequestReport]</td>', (
											select case when (@tempTextField001 + @tempTextField002) = '' then '<td class=''DiscrepanciesWithinThreshold''>Everything is fine</td><td class=''DiscrepanciesWithinThreshold''>No action required</td>' 
													when @tempTextField001 <> '' then ('<td class=''DiscrepanciesAboveThreshold''>' + @tempTextField001 + @tempTextField002 + '</td>' + '<td class=''DiscrepanciesAboveThreshold''>' + @tempTextField003 + @tempTextField004 + '</td>')
													else '<td class=''DiscrepanciesWithinThreshold''>' + @tempTextField002 + '</td>' + '<td class=''DiscrepanciesWithinThreshold''>' + @tempTextField004 + '</td>' end ))

				;WITH xmlnamespaces(DEFAULT 
				'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
				) 
				select @emailMessage = REPLACE(@emailMessage, '<td>[PlSpStReport]</td>', (
											select 
											case when (
											--# of requests in archive in last 24 hours [normal| no requests]
											case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
											--# of requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
											--# of failed requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
											--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
											--# of requests in queue in progress for 3+ hours [normal| no requests]
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours' else '' end

											) = '' then '<td class=''DiscrepanciesWithinThreshold''>Everything is fine</td><td class=''DiscrepanciesWithinThreshold''>No action required</td>' else (

											'<td class=''DiscrepanciesAboveThreshold''>' --# of requests in archive in last 24 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
											--# of requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
											--# of failed requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
											--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
											--# of requests in queue in progress for 3+ hours [normal| no requests]
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours<br/>' else '' end
											+'</td><td class=''DiscrepanciesAboveThreshold''>'
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'Critical issue! This implies that Salesforce sftp server might have taken our service unresponsive<br/>Restart the InterchangeFileProcessor worker role instances of Azure cloud services<br/>' else '' end
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'Proactive measure! This could imply that Salesforce sftp server might have taken our service unresponsive<br/>Check the logs and restart the InterchangeFileProcessor worker role instances of Azure cloud services (<i>if and only if it is necessary</i>)<br/>' else '' end
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then 'Investigate on these failures, report it to concerned people<br/>' else '' end
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Too many requests are in queue waiting for Azure worker role<br/>Restart the InterchangeFileProcessor worker role instances of Azure cloud services<br/>' else '' end
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Low priority! This could imply that process completed; requests are waiting for getting archived<br/>Check the logs & azure table storage<br/>' else '' end
											+'</td>'
											) end
											from requestqueue rq1 with (nolock)
											full outer join requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
											where (convert(date, rq1.createddatetime) >= convert(date, getutcdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getutcdate()-1))
											and (rq1.requesttype in ('PromotionalListData', 'SuppressionPromotionalData', 'SuppressionTransactionalData') or rq2.requesttype in ('PromotionalListData', 'SuppressionPromotionalData', 'SuppressionTransactionalData'))
											and rq2.requestid not in (select distinct EmailInterchangeId from transactionallog with (nolock)
											where EventId=201130011 and MessageString like '%does not have access to ClientID%'))
											)

				;WITH xmlnamespaces(DEFAULT 
				'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
				) 
				select @emailMessage = REPLACE(@emailMessage, '<td>[FtdReport]</td>', (
											select 
											case when (
											--# of requests in archive in last 24 hours [normal| no requests]
											case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
											--# of requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
											--# of failed requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
											--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Azure File Notifier Service is unresponsive<br/>' else '' end
											--# of requests in queue in progress for 3+ hours [normal| no requests]
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours' else '' end

											) = '' then '<td class=''DiscrepanciesWithinThreshold''>Everything is fine</td><td class=''DiscrepanciesWithinThreshold''>No action required</td>' else (
											'<td class=''DiscrepanciesAboveThreshold''>' --# of requests in archive in last 24 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'No requests completed in last 24 hours<br/>' else '' end
											--# of requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests completed in last 2 hours<br/>' else '' end
											--# of failed requests in archive in last 2 hours [normal| no requests]
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then convert(nvarchar(max), sum(case when rq2.IsFailedstate = 2 then 1 else 0 end)) +' requests failed in last 24 hours<br/>' else '' end
											--# of requests in queue waiting for 2+ hours for a slot [normal| no requests]
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then convert(nvarchar(max), sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end))+' requests are waiting to upload the data file in Salesforce sftp server for 2+ hours<br/>This implies that Salesforce sftp server might have taken our service unresponsive<br/>' else '' end
											--# of requests in queue in progress for 3+ hours [normal| no requests]
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Just for information. '+ convert(nvarchar(max), sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end))+' requests are waiting to be archived for 3+ hours<br/>' else '' end
											+'</td><td class=''DiscrepanciesAboveThreshold''>'
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 then 'Critical issue! This implies that Salesforce sftp server might have taken our service unresponsive<br/>Restart Azure File Notifier Service<br/>' else '' end
											+case when sum(case when rq2.isfailedstate is not null then 1 else 0 end) = 0 and sum(case when rq2.isfailedstate is not null and datediff(hour, rq2.createddatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'Proactive measure! This could imply that Azure File Notifier Service is unresponsive<br/>Check the logs and restart Azure File Notifier Service (<i>if and only if it is necessary</i>)<br/>' else '' end
											+case when sum(case when rq2.IsFailedstate = 2 then 1 else 0 end) > 5 then 'Investigate on these failures, resubmit the requests using resubmit tools available and report it to concerned people (if absolutely necessary)<br/>' else '' end
											+case when sum(case when rq1.isprocessing = 0 and rq1.isFailedState = 0 and datediff(hour, rq1.createddatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Too many requests are in queue waiting for Azure File Notifier Service<br/>Restart Azure File Notifier Service<br/>' else '' end
											+case when sum(case when rq1.isprocessing = 1 and datediff(hour, rq1.createddatetime, getutcdate()) >= 3 then 1 else 0 end) > 0 then 'Low priority! This could imply that process completed; requests are waiting for getting archived<br/>Check the logs & azure table storage<br/>' else '' end
											+'</td>'
											) end
											from requestqueue rq1 with (nolock)
											full outer join requestarchive rq2 with (nolock) on rq1.requestid = rq2.requestid
											where (convert(date, rq1.createddatetime) >= convert(date, getutcdate()-1) or convert(date, rq2.createddatetime) >= convert(date, getutcdate()-1))
											and (rq1.requesttype = 'FileTriggerData' or rq2.requesttype = 'FileTriggerData')
											and rq2.requestid not in (select distinct EmailInterchangeId from transactionallog with (nolock)
											where EventId=201130011 and MessageString like '%does not have access to ClientID%'))
											)

				SELECT convert(nvarchar(max),@emailMessage) as [EmailMessage]
				, case when @emailMessage like '%DiscrepanciesAboveThreshold%' then 'Azure: red' else 'Azure: green' end as [EmailSubject]
				, case when @emailMessage like '%DiscrepanciesAboveThreshold%' then 0 else 1 end as [CodeGreen];