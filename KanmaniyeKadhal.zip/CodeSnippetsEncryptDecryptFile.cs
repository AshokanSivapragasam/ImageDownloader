/// <summary>
/// This method encrypts a file
/// </summary>
/// <param name="encryptionKey">Key used to encrypt the file</param>
/// <param name="sourceFileName">File name to be encrypted</param>
/// <param name="targetFileName">Target file name to be created with encryption</param>
/// <param name="deleteSourceFile">Boolean flag to delete Source file</param>
public void EncryptFile(string sourceFileName, string targetFileName, string encryptionKey)
{
	if (string.IsNullOrWhiteSpace(sourceFileName))
		throw new ArgumentNullException(sourceFileName);

	if (string.IsNullOrWhiteSpace(targetFileName))
		throw new ArgumentNullException(targetFileName);

	using (FileStream fileStreamCrypt = new FileStream(targetFileName, FileMode.Create))
	{
		using (RijndaelManaged rijndaelManagedCrypto = new RijndaelManaged())
		{
			rijndaelManagedCrypto.Mode = CipherMode.CBC;
			using (PasswordDeriveBytes secretKey = new PasswordDeriveBytes(encryptionKey, Encoding.ASCII.GetBytes(encryptionKey.Length.ToString(CultureInfo.InvariantCulture))))
			{
				using (CryptoStream cs = new CryptoStream(fileStreamCrypt, rijndaelManagedCrypto.CreateEncryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)), CryptoStreamMode.Write))
				{
					using (FileStream fileStreamIn = new FileStream(sourceFileName, FileMode.Open))
					{
						int data;
						while ((data = fileStreamIn.ReadByte()) != -1)
						{
							cs.WriteByte((byte)data);
						}

						fileStreamIn.Flush();
						cs.FlushFinalBlock();
					}
				}
			}
		}
	}
}

/// <summary>
/// This method decrypts a file
/// </summary>
/// <param name="request">Actual Request</param>        
/// <param name="destinationFile">file path to where we are placing the decrypted file</param>
public void DecryptFile(string sourceFile, string destinationFile, string decryptionKey, int maximumRetryAttempts = 1)
{
	if (string.IsNullOrWhiteSpace(sourceFile))
		throw new ArgumentNullException("Input file is not valid");

	if (string.IsNullOrWhiteSpace(decryptionKey))
		throw new ArgumentNullException("DecryptionKey is not valid");

	try
	{
		using (FileStream fsCrypt = new FileStream(destinationFile, FileMode.Create))
		{
			using (RijndaelManaged rmCrypto = new RijndaelManaged())
			{
				rmCrypto.Mode = CipherMode.CBC;
				using (PasswordDeriveBytes secretKey = new PasswordDeriveBytes(decryptionKey, Encoding.ASCII.GetBytes(decryptionKey.Length.ToString())))
				{
					using (CryptoStream cs = new CryptoStream(fsCrypt, rmCrypto.CreateDecryptor(secretKey.GetBytes(32), secretKey.GetBytes(16)), CryptoStreamMode.Write))
					{
						using (FileStream fsIn = new FileStream(sourceFile, FileMode.OpenOrCreate))
						{
							int data;
							while ((data = fsIn.ReadByte()) != -1)
								cs.WriteByte((byte)data);
						}
					}
				}
			}
		}
	}
	catch (Exception ex)
	{
		Console.WriteLine(ex.Message);
	}
}
