
;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select top 10
'PartitionKey eq '''+lower(requestid)+''''
,datediff(minute, createddatetime, getutcdate())
,object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)')
,object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
,* 
from dbo.requestqueue with (nolock)
where convert(date, createddatetime) = convert(date, getutcdate())
and isfailedstate <> 2
order by createddatetime desc

;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select top 10 
'PartitionKey eq '''+lower(requestid)+''''
,datediff(minute, createddatetime, completeddatetime)
,object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)')
,object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
,* 
from dbo.requestarchive with (nolock)
where convert(date, createddatetime) = convert(date, getutcdate())
order by createddatetime desc

select top 500 getutcdate(),* from systemlog with (nolock)
where eventid between 21701 and 21730
order by requestlogdatetime desc

select top 100 getutcdate(), * from vwrequest with (nolock)
where requeststartdatetime between getutcdate()-1 and getutcdate()
and requesttype = 'wizarddata'
order by requeststartdatetime desc

--select top 10 * from systemlog order by createddatetime desc
--select top 10 * from transactionallog order by createddatetime desc
select top 10 * from transactionallog
where emailinterchangeid = '29CF064F-35DB-4668-A2B1-745C3E0F9E86'

select * from bulksendconfiguration
select * from interchangeuser
select * from bulksendclassification
select * from enterpriseaccount

select getutcdate()

select * from LastPulledIdentifierOfMsiFile
--MMO	20150306163305
--Tenant1	19000101010101
--Tenant2	19000101010101
--Tenant3	20150306163303
--YMR	20150306163312

select * from MsiTenantDetails

--update msitenantdetails
--set SftpDestinationDirectory = 'export\YmrResponseFiles',
--SftpArchiveDirectory='export\ArchivedYmrFiles'
--where TenantName = 'YMR'

select ProcessingStatus, 
datediff(minute, FileProcessingStartDateTime, (case when ProcessingStatus in ('Completed', 'Block', 'PermanentlyBlocked') then FileProcessingEndDateTime else getutcdate() end ))
, getutcdate(),*
--delete 
from MsiFileSupervisor
select * from PoolMsiFileSupervisor

--GetAnMsiFileInChronologicalOrder
--GetAnMsiFileInChronologicalOrder

exec GetMSITenants

select EnterpriseAccountId, WebClientUserName, WebClientPassword, SFTPClientUserName, SFTPClientPassword, EnterpriseAccountName, PollExactTarget, ExactTargetURL, ExactTargetSFTPURL, ExactTargetCertificateName, UseETCertificate

--delete from [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  

--INSERT INTO [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  VALUES ('MMO','19000101010101') 
--INSERT INTO [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  VALUES ('YMR','19000101010101') 
--INSERT INTO [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  VALUES ('Tenant1','19000101010101') 
--INSERT INTO [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  VALUES ('Tenant2','19000101010101') 
--INSERT INTO [dbo].[SortIdentifierOfPreviouslyProcessedMsiFile]  VALUES ('Tenant3','19000101010101') 


--delete from [dbo].[MsiTenantDetails]

/*
INSERT INTO [dbo].[MsiTenantDetails]
      ([TenantName]
	  ,[SftpServer]
      ,[SftpUser]
      ,[SftpPassword]
      ,[SftpSourceDirectory]
      ,[SftpDestinationDirectory]
      ,[SftpArchiveDirectory]
      ,[ExtensionToWatch]
      ,[RegexPatternForFilenameConvention])
VALUES 
('MMO', 'ftp.test.exacttarget.com','39327','il6xX02M9ruHEr90R7y7LbMu9luVhoe++0kz4K1jRDCMyUBczyRHXBniO2MlLS9CiDIuka/xu3m8amJiG7O9Wgc5uQcdiBnCGQAw1Fc10Fp0b3hMaYevNGwr7AXmXCU+biNrwmpjUcxDigKU+fEAwREYSwCrPTDF2yERRlmTuiHaQ+AWgv6JRLClJLzPJx6uQ0PDJ9V+LjHxsqdE6Exjb8b1vdxQlyr7l9Uu5ZuLTPPASqYNEOlWXPjuANtp8OHq0s41BZk1bj2nDOfNmvuwoqZYIHC5YQ/IHmCHBLBe/Sh9TGDbDByd6HMyBRcdS634OOb8RTJHDWOz9/gqYfCMag==',
'export\MmoFiles','import\MmoResponseFiles','export\ArchivedMmoFiles','.aes','_(\d{14})_(\d+)'),
('YMR', 'ftp.test.exacttarget.com','39327','il6xX02M9ruHEr90R7y7LbMu9luVhoe++0kz4K1jRDCMyUBczyRHXBniO2MlLS9CiDIuka/xu3m8amJiG7O9Wgc5uQcdiBnCGQAw1Fc10Fp0b3hMaYevNGwr7AXmXCU+biNrwmpjUcxDigKU+fEAwREYSwCrPTDF2yERRlmTuiHaQ+AWgv6JRLClJLzPJx6uQ0PDJ9V+LjHxsqdE6Exjb8b1vdxQlyr7l9Uu5ZuLTPPASqYNEOlWXPjuANtp8OHq0s41BZk1bj2nDOfNmvuwoqZYIHC5YQ/IHmCHBLBe/Sh9TGDbDByd6HMyBRcdS634OOb8RTJHDWOz9/gqYfCMag==',
'export\YmrFiles','import\YmrRespnseFiles','export\ArchivedYmrFiles','.aes','_(\d{14})'),
('Tenant3', 'ftp.test.exacttarget.com','39327','il6xX02M9ruHEr90R7y7LbMu9luVhoe++0kz4K1jRDCMyUBczyRHXBniO2MlLS9CiDIuka/xu3m8amJiG7O9Wgc5uQcdiBnCGQAw1Fc10Fp0b3hMaYevNGwr7AXmXCU+biNrwmpjUcxDigKU+fEAwREYSwCrPTDF2yERRlmTuiHaQ+AWgv6JRLClJLzPJx6uQ0PDJ9V+LjHxsqdE6Exjb8b1vdxQlyr7l9Uu5ZuLTPPASqYNEOlWXPjuANtp8OHq0s41BZk1bj2nDOfNmvuwoqZYIHC5YQ/IHmCHBLBe/Sh9TGDbDByd6HMyBRcdS634OOb8RTJHDWOz9/gqYfCMag==',
'export\Tenant3Files','import\Tenant3ResponseFiles','export\ArchivedTenant3Files','.aes','_(\d{14})_(\d+)'),
('Tenant1', 'ftp.test.exacttarget.com','39327','il6xX02M9ruHEr90R7y7LbMu9luVhoe++0kz4K1jRDCMyUBczyRHXBniO2MlLS9CiDIuka/xu3m8amJiG7O9Wgc5uQcdiBnCGQAw1Fc10Fp0b3hMaYevNGwr7AXmXCU+biNrwmpjUcxDigKU+fEAwREYSwCrPTDF2yERRlmTuiHaQ+AWgv6JRLClJLzPJx6uQ0PDJ9V+LjHxsqdE6Exjb8b1vdxQlyr7l9Uu5ZuLTPPASqYNEOlWXPjuANtp8OHq0s41BZk1bj2nDOfNmvuwoqZYIHC5YQ/IHmCHBLBe/Sh9TGDbDByd6HMyBRcdS634OOb8RTJHDWOz9/gqYfCMag==',
'export\Tenant1Files','import\Tenant1ResponseFiles','export\ArchivedTenant1Files','.aes','_(\d{14})_(\d+)'),
('Tenant2', 'ftp.test.exacttarget.com','39327','il6xX02M9ruHEr90R7y7LbMu9luVhoe++0kz4K1jRDCMyUBczyRHXBniO2MlLS9CiDIuka/xu3m8amJiG7O9Wgc5uQcdiBnCGQAw1Fc10Fp0b3hMaYevNGwr7AXmXCU+biNrwmpjUcxDigKU+fEAwREYSwCrPTDF2yERRlmTuiHaQ+AWgv6JRLClJLzPJx6uQ0PDJ9V+LjHxsqdE6Exjb8b1vdxQlyr7l9Uu5ZuLTPPASqYNEOlWXPjuANtp8OHq0s41BZk1bj2nDOfNmvuwoqZYIHC5YQ/IHmCHBLBe/Sh9TGDbDByd6HMyBRcdS634OOb8RTJHDWOz9/gqYfCMag==',
'export\Tenant2Files','import\Tenant2ResponseFiles','export\ArchivedTenant2Files','.aes','_(\d{14})_(\d+)')*/

select top 10 * from transactionallog 
order by createddatetime desc

select top 10 * from systemlog
order by createddatetime desc

select top 10 * from request
order by startdatetime desc

select * from communication c 
inner join [language] l on l.languageid = c.languageid
inner join [country] cy on cy.countryid = c.countryid
where c.communicationid = 125905

select * from 
dbo.ExactTargetCommunicationSummary etcs
inner join dbo.GenesisCommunicationSummary gcs	on gcs.ReportForDate = etcs.ReportForDate
where etcs.ReportForDate in
(select ReportForDate from dbo.CommunicationSummaryTable cst
where convert(date, ReportForDate) = '2015-05-09'
group by ReportForDate
having sum(case IsDataPulledFromDatasystem when 1 then 1 else 0 end) = 2)

--insert into dbo.GenesisCommunicationSummary
--(ReportForDate,TotalNumberOfCommunications,TotalNumberOfActiveCommunications,TotalNumberOfCommunicationClass,ReportGeneratedDatetime,RecordInsertedDatetime)
--select ReportForDate,TotalNumberOfCommunications,TotalNumberOfActiveCommunications,TotalNumberOfCommunicationClass,ReportGeneratedDatetime,RecordInsertedDatetime from
--dbo.ExactTargetCommunicationSummary

exec [spDelagateWorkToCommunicationSummarySupervisor] 'Genesis' 
exec [spDelagateWorkToCommunicationSummarySupervisor] 'ExactTarget'

select distinct gcs.*, scs.*, ecs.* 
from dbo.CommunicationSummarySupervisor css
left join GenesisCommunicationSummary gcs on gcs.ReportForDate = css.ReportForDate
left join SubscriptionMgmtCommunicationSummary scs on scs.ReportForDate = css.ReportForDate
left join ExactTargetCommunicationSummary ecs on ecs.ReportForDate = css.ReportForDate
where css.ReportForDate >= '2015-05-19' and (gcs.UniqueId is not null or scs.UniqueId is not null or ecs.UniqueId is not null)
FOR XML RAW ('Request'), ROOT ('Requests'), ELEMENTS;


/* To prevent any potential data loss issues, you should review this script in detail before running it outside the context of the database designer.*/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.CommunicationSummary ADD
	AdditionalInfo bigint NULL
GO
ALTER TABLE dbo.CommunicationSummary SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

insert into ReconciliationTaskConfiguration
(NameOfTask, MediumOfDatasource, DriverXmlFileRelativePath)
values 
('Genesis_Database_DataPull', 'Database', 'DriverFiles\Genesis_Database_DriverFile.xml'),
('SubscriptionManagement_Database_DataPull', 'Database', 'DriverFiles\SubscriptionManagement_Database_DriverFile.xml'),
('ExactTarget_Email_DataPull', 'Email', 'DriverFiles\ExactTarget_Email_DriverFile.xml'),
('ExactTarget_Sftp_DataPull', 'Sftp', 'DriverFiles\ExactTarget_Sftp_DriverFile.xml')

SELECT * from ReconciliationTaskConfiguration rtc with (nolock)
left join ReconciliationTaskRequestQueue rtrq with (nolock) on rtrq.ReportForDate = '2015-05-21' and rtc.NameOfTask = rtrq.NameOfTask
where (rtrq.UniqueId is null or (rtrq.IsTaskCompleted = 0 and rtrq.StatusOfTask in ('Failed')))
and rtc.MediumOfDatasource = 'Database'


WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY [Application], MachineName 
        order by RequestDateTime desc
    ) AS RowNo 
    FROM TransactionalLog with (nolock)
	Where MessageType = 'Exception'
	AND RequestDateTime BETWEEN dateadd(year, -1, getutcdate()) AND getutcdate()
)
SELECT * FROM TOPTEN WHERE RowNo <= 10
order by RequestDateTime desc, MachineName


--Count number of oocurrences of a substring in a string
Declare @string varchar(1000)
DECLARE @SearchString varchar(100)
Set @string = 'as as df df as as as dfe'
SET @SearchString = 'as'

select ((len(@string) - len(replace(@string, @SearchString, '')))
					  - (len(@string) - len(replace(@string, @SearchString, ''))) % 2
		)  / len(@SearchString)
		

WITH TOPTEN AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY [group_by_field] 
        order by [prioritise_field]
    ) AS RowNo 
    FROM [table_name]
)
SELECT * FROM TOPTEN WHERE RowNo <= 10


;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select top 10
'PartitionKey eq '''+lower(requestid)+''''
,datediff(minute, createddatetime, getutcdate())
,object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)')
,object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
,* 
from dbo.requestqueue with (nolock)
where convert(date, createddatetime) = convert(date, getutcdate())
and requesttype = 'triggeredrequest'
and isfailedstate <> 2
order by createddatetime desc

;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select top 100
'PartitionKey eq '''+lower(requestid)+''''
,datediff(minute, createddatetime, completeddatetime)
,object.value('(/InterchangeFileRequest/ProcessStatus)[1]', 'nvarchar(max)')
,object.value('(/Request/SourceFileName)[1]', 'nvarchar(max)')
,object.value('(/TriggeredRequest/CustomerKey)[1]', 'nvarchar(max)') 
,object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''CustomerEmail'']/Value)[1]', 'nvarchar(max)')
,object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''cc_recipients'']/Value)[1]', 'nvarchar(max)')
,object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''CcRecipients'']/Value)[1]', 'nvarchar(max)')
,* 
from dbo.requestarchive with (nolock)
where convert(date, createddatetime) >= '2016-07-20'
and requesttype = 'triggeredrequest'
and tenantname = 'c2pc'
--and object.value('(/TriggeredRequest/CustomerKey)[1]', 'nvarchar(max)') = 'Lead_Pool' 
and object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''PartnerMPNId'']/Value)[1]', 'nvarchar(max)') = '732183'
and (object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''cc_recipients'']/Value)[1]', 'nvarchar(max)') like '%klaserna@managedsolution.com%'
or object.value('(/TriggeredRequest/Subscribers/SubscriberBase/Attributes/Attribute[Name=''CcRecipients'']/Value)[1]', 'nvarchar(max)') like '%klaserna@managedsolution.com%')
order by createddatetime desc

ALTER DATABASE [old_name] SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
ALTER DATABASE [old_name] MODIFY NAME = [new_name]
GO
ALTER DATABASE [new_name] SET MULTI_USER
GO


;WITH xmlnamespaces(DEFAULT 
'http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Email.Common.Core'
) 
select top 2
RequestId as EiRequestId
,object.value('(/TriggeredRequest/Subscribers/SubscriberBase/EmailAddress)[1]', 'nvarchar(max)') EmailAddress
,object.value('(/TriggeredRequest/CustomerKey)[1]', 'nvarchar(max)') CustomerKey
,object.value('(/TriggeredRequest/ConversationId)[1]', 'nvarchar(max)') ConversationId
,object.value('(/TriggeredRequest/AccountId)[1]', 'nvarchar(max)') AccountId
,CreatedDateTime ReceivedDateTime
,CompletedDateTime
,'Success' [Status]
,Tenantname as AppFriendlyName
,*
from requestarchive with (nolock)


--History of queries

SELECT t.[text]
FROM sys.dm_exec_cached_plans AS p
CROSS APPLY sys.dm_exec_sql_text(p.plan_handle) AS t
WHERE t.[text] LIKE N'%something unique about your query%';

<InterchangeRIOQueueMessagePhx xmlns="http://schemas.datacontract.org/2004/07/Microsoft.IT.RelationshipManagement.Interchange.Platform.Azure.Services.Common" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><Id>5fd39756-aeb2-4cf2-b558-524572985631</Id><RequestType>ReportExtractData</RequestType><Tenant>InterchangeETProcessor</Tenant><TenantId>1</TenantId><UserId>0</UserId><Domain>PHX</Domain><EnterpriseAccountId>39327</EnterpriseAccountId><FileSizeInBytes i:nil="true"/><RequestProcessingFileName>CustomerRefresh_39327_04022015.aes</RequestProcessingFileName><RequestProcessingStatus>ReadyToProcess</RequestProcessingStatus><SubsidiaryAccountId>39327</SubsidiaryAccountId></InterchangeRIOQueueMessagePhx>

https://www.saavn.com/s/album/tamil/Naerukku-Naer-Film-Story-2012/8iuYL7iRKUM_