Idea-RequestResubmission

PL/SP/ST:
----------

1. Overview:
-------------
	1.1 For file-based requests, we can re-drop the file in the drop location
	1.2 EI File Notification Service will pick up the files and create new requests for the new files
	1.3 That's how it is done

2. Technical overview:
-----------------------
	2.1 Run the query that gets list of all filtered requests
	2.2 Select the requests that should be re-initiated
	2.3 Say 'Resubmit'
	2.4 I will get selected requests and RequestObject so that I can infer the following data
		- EncryptedFileName (EtId.aes)
		- DropLocation (..\Drop\)
		- FileExtension (.ext)
		- ArchiveLocation (..\Edge\Archive\EiId)
		- EiRequestID (EiId)
		- OriginalFileName (filename.ext)
	2.5 To re-submit, I will re-initiate the requests by
		- Decrypt file in edge location
		- Decompress file in edge location
		- Move file to drop location
	2.6 Rest is with File Notification Service :)

3. Modules
	3.1 Fetch filtered results using sql query
	3.2 Re-initiate requests
	3.3 Update old requests to attendance tracker table
	
TBN:
----------

1. Overview:
-------------
	1.1 For file-based requests, we can re-drop the file in the drop location
	1.2 EI File Notification Service will pick up the files and create new requests for the new files
	1.3 That's how it is done

2. Technical overview:
-----------------------
	2.1 Run the query that gets list of all filtered requests
	2.2 Select the requests that should be re-initiated
	2.3 Say 'Resubmit'
	2.4 I will get selected requests and RequestObject so that I can infer the following data
		- EncryptedFileName (EtId.aes)
		- DropLocation (..\Drop\)
		- FileExtension (.ext)
		- ArchiveLocation (..\Edge\Archive\EiId)
		- EiRequestID (EiId)
		- OriginalFileName (filename.ext)
	2.5 To re-submit, I will re-initiate the requests by
		- Decrypt file in edge location
		- Decompress file in edge location
		- Move file to drop location
	2.6 Rest is with File Notification Service :)

3. Modules
	3.1 Fetch filtered results using sql query
	3.2 Re-initiate requests
	3.3 Update old requests to attendance tracker table