1. EI Bulk-send processor is not waiting for ET to complete its data import activity
		Compress
		Encrypt
		UploadToSftp
		CreateFtoRequestAtExactTarget
		CreateDataExtension

2. EI is not failing Bulk-send request if it cannot create bulk-send definition
		- EmailContent
		- Create Data Extension
		- SendDefinition (EmailContentID, DeRefKey, SendClassification)

3. EI is not keeping file (>2mb) integrity while uploading the file from tenant location to azure blob
		- Uploading synchronously

4. EI is throwing null reference exception when user pass invalid send-classification key which is not available for their EI Onboarding
		- Safe code
		
5. Failover processor is not functional; it is supposed to process all failed TBN & Bulk-send requests.
		- Keep it in sync with TBN & Bulk-send processor
		
6. Bug#23650: EmailResponseData requests processed successfully but the database status is showing as "Failed"
		- ResponseCode = MdmConnectorApi(EmailAddress, IsContactable, IsNdr[Soft|Hard])
			+ve & -ve

/*Bulk-send flow*/
#1st phase
	1. Create request (Fto)
	2. Create data extension
	3. Compress the blob
	4. Encrypt the blob
	5. Upload the blob
	6. Update the status to EI System
---------------------------------------> Exception(Can be resumed)
#2nd phase
	1. Query request (Fto)
	2. Create bulk-send definition
	3. Update request (Fto)
	4. Update the status to EI System
---------------------------------------> Exception(Can be resumed)
	5. Retry if ET is not complete --> Hide the message for more 5 mins; Increment number of attempts as well; Escape from this job
	
Compress (EiId.gz)
Request creation (EtId)
Encrypt (EtId.aes)
Upload (EtId.aes)

Dev reproduce
	Phase 001
	---------
	Compress (EiId.gz)
	Request creation (EtId)
	Encrypt (EtId.aes) --> EtId -- 0000-0000-00000000-0000.aes
	Upload (EtId.aes)
	
	Et import (EtId.aes); import cannot happen; Et is waiting infinite time
	
	Actual: Status of Request ET Data Activity Complete
	Expected: Status of Request ET Program Complete
	
	--Wait time for Et to do its activities (Currently, queue invisible time : 5 minutes; 1 minute)
	
	Phase 002
	---------
	Check whether status of Request ET Program Complete or not
	if(completed)
		then it will create bulk-send defn
	if not (not error)
		then it will be re-queued (number of attempts)
	else
		then it will decline

http://www.binpress.com/blog/2014/06/26/polymer-vs-angular/