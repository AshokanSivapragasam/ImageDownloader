#Azure solution for Email Interchange:

/*Email Response data*/
1. It is being served by InterchangeETProcessor
2. QUEUE REQUESTS
	2.1 It gets the new requests (FTO) from ET by using ET custom query text
		Note: It compromises security; gets new object from ET Api
	2.2 It converts ETO to EIO and import request at EI
	2.3 It gets FTO+RCM by Id; updates the status at ET
	2.4 It marks the request as 'ready'
3. PROCESS REQUESTS
	3.1 Get all ready requests of type 'Email Response'; read one by one
	3.2 Download file from SFTP and other file based operations
	3.3 Load file contents to datatable and pass to MSIConnector
	3.4 MSIConnector will unsubscribe each CommID associated with customer
	3.5 MDMConnector will update visibility of the NDR email list
	3.6 Updates the status of requests at ET
	
/*Report Extract data*/
1. It is being served by InterchangeETProcessor
2. QUEUE REQUESTS
	2.1 It gets the new requests (FTO) from ET by using ET custom query text
		Note: It compromises security; gets new object from ET Api
	2.2 It converts ETO to EIO and import request at EI
	2.3 It gets FTO+RCM by Id; updates the status at ET
	2.4 It commit the message to queue called, 'InterchangeRIOQueueMessage'
3. EI PULL SERVICE
	3.1 Get all messages from queue called, 'InterchangeRIOQueueMessage'
	3.2 Update messages in the queue as 'InProgress'
	3.3 Download file from SFTP and other file based operations
	3.4 Drop the file(s) in target location (given by GetRioExtractReceivedPath)
	3.5 It commits the processed messages to queue called, 'InterchangeRIOProcessedQueueMessage'
4. UPDATE EXTACTTARGET STATUS FOR RIO REQUESTS
	4.1 It monitors the queue called, 'InterchangeRIOProcessedQueueMessage' for passed & failed requests
	4.2 Updates the status of requests at ET

#OnPremise Db Connection String:
miGdz4Kl09AqLmHoO/FyKdXPIhfYMk4hr8wGPKS4SOOyQy9rpmJYRS+uR7MpTFVY1cakKU0JAmVMQC5gK6xtTtfgBhDEwLHQ8nwGv5r0IoaWnD/nXZHQAJgZuBfBd9WpxqjQqehStISYX0Q0BCgX67+cSNzAzRxIuwNL6K9L1otog7UHsSPKFbug+AiLpKbADqzr/CiC6EHYXlL+lEbISqarBZa07eeYGckdk0CxZen5kKUdE/HJsPJ6cuT0rK9EsLswGC6wKGxj6hJQHS3AV/Kcb03OSeX5dKpsJy/NYw8Xu7wfHh6QCMYHdM0juzK2lBb0lpaNKYPxfva0OND85g==
	
#Diagnostics Connection String:
	ZB/ra3pG9nF39aJPtWeCcxI6jQQgNpY3m5jYfNUCWOF5LaRFxvfS6vwpnBC1MpEAYJDKbXzSM1n+fj0elcyJkjnxWep7nsJamcdXLvsLgtw9nsG6beXheav/HkWtxDcjhFnuMHqv1pAclARlOhEvm/zNfzh/lFnGN2wmgSGBz/UJiohfxhMlbOYEvU3DWZD3wf7o0nIWgGlkyrjCyJcRzMPgKih9Pe6PofnTEkhQdxNCFH06MyBLHB/6g6qRZz/h8kb715aWUC8OQdTdGyXKlGaMDUZjfpuwzqulAyeQ/nTKwPmjw6oYMUDhT7D6SAaQ+e3JGuOFYTdOMJce9KinKQ==

#Interchange Db Connection String:
	g1ruP6b7A0RP1BtTpMUaf2iNnRAuTpmw4nS3W6nqHZOvJO1RMmfmxzT6TdhNN1pHSqvde4GBThlyh9s/Ms+IM2skEh4rSDUlb6kQxm38Ojk2jhuIhKH3oAVjFayTWszvDqyEvizOQxlUl/KxVnHMIqq42xR1M61rqYiWkbGxqVfyEOSOgzdYCG0FFKV0T4rGxc3VCJqHRIPw9LEC6twiKpkogT/76zq7ea2BgCDnr/5c31qqtgpb2PRE1Tz4Wu1QXbWHu5q6fBvhqOSiNfagDBnQhcLQ0AJaiUNn7O2/qpyN7HyF94ay+H3uJGGpL92sC6cR3Et5l7Mna95AfBQZTA==

#Interchange Storage Connection String:
	EdC9i7CjZlh7kQXG8maf7I5HA+hoY9sXVGJOeVocCKqG32KWCgHq5RQrqZb826w3AUvphfKw4PrsVD5o5gQxwuLobDSOxfmxK9XnjHKVlQpsXlIjORpSVp7b/N+WMVSwW0tnxmdUJWnj1yjhihue9FwBjvLyVeuGq8In4uQyNrmq/LhuS9TmL8KFyKHRbKopJ1qCPtCpH8LeD5kp0uMKPcNAK1mt/4VzgO0YxULgz6jKw7Ji3m6PkbNT72gEpU8M6tJBVicXym+hr4h6oFpqhp7LjdhQnIq5R910/VtHVOjfZjaqtDsFTZ/6jtKlxtX715omvPvUirtQzVNn/zefWw==

#Exact Target User: 
	WCpIMwZEVQZXq6b7sqRymPN1BIMt5sEpsVJWjZjKA3dwVcmAv3K5G3cATR82jPcNND7PID6ojDmOLDiip4etN0xUVV7dl9NyMqVaqIxO/0qAdgVl/k+G0Wr6ioLx2K/eS3wP8VxuPA5IOasIBcu8te8KJEBMZAlWI6sMd99+xbAePEeDqjs6rz4ecDS/98+lyttGJMrhMVJLGRx4UwWuBwBozn6trMFC5B5KXqr8izc8EQpkSsWuSOF7nRauPBPsdAjVg2CCjeQ242dywb3PL7JDnpVQAvm8eSgESOSm3jAU7fGM0Agd/jJWstSncTMFyC+zEIapmet2G7oz3mPYhA==

#Exact Target Password:
	P8m3kFoRdEC4zeG2LvIMAXOhy8c89y1TMPeLKkWWO9RDLGeC9ciJO0dIccdeT7ODO3+XzUOaKbjnDKExJmhGGOELzH7xTfxuWSnI7LYSKPeHt1S11nxs/xlZY/4xLbPiyVp5+XzYJ/m+tQWPpkW8JqtZ/1cXrPQ9ST7DtE6x0+VniXh6AY/oQSvUM0WPDtMqvb0oJTBAEs0+JTUcHmMksSdT+p0n0OPU41R0Dw9wQTrIZjr+jyGBK1ISussZBvNKdHSuUr/LGhEU9aKZAbL4uILYeqnq+4KHj2rVKeKuY7z3t5Y9DWdQQ/B8tVfHWH3DlqofgIJpI1AaZrhb+vUrcA==
	
#Azure SubscriptionId: (ca87dc93-813b-492f-8140-11918ab89fab)
	eNmr+BSlc9BW9Aap7+BGLshOdEWddShUHzsGHXNVDk+S40ISszekJvIOVX/q/sK7AyZjPtNEar8wMT7oAqbOsr66ctbDo8cHz0+xacIH3nDTwN0ATwCoD3IhhY906xlWHI/W3Z6quT0/+LOvmxb1rM8vZdggl+66/v2WyKneCLG5FkMb2ow95myK7/iyfXqGEEDnBmMTyMQV0BNWZaUHV03242yHoJmTqiyIdUb6jTJ8LnP0sL5nRSy7S6mlXGw9h7lcaGxnciolR97plGLXxEY4k2uUFlsCNMIMzkI5iypbks7DJEGIpAnRvQQd744IR8Molj/fUFPHatUfHr7AsA==
	
#SbIssuer: (owner)
	P+PVgKquxSBdlZbYYTySAlSCE/OxArp4jlPSXQA7F9ULS5BQj4niq5QbM75C5B7EmiGbbFpoDm5S+/iTMprHoIjQLIf5QAnllWLC3XeQz1GmBapsklseEa6eujel+zTR0Yplz6eNP5IgHzClmvM21xvGp5th3feeUoG/byJ+d3ZnB9tR+Aw/6OINmK0VM1mdEDiYuZfqsfxX3M7AIVU6F+soSgLeP5ZZrh4/hV4v+16KeOC7vMiMOB5rYz2eMLlefe8Q5YkhF2TffujX+tYDWl5xBQVP4ZUPWUBEFL7hn+csQhjS8QDqgHCa07P46b/yg88usLdbHOc3y/czSxSQZw==

#SbIssuerSecret: (iykyWPA6QK87/GDNeGVduC2cO4SDwMs1pmi/DX77yTo=)
	HzSo2KNPrTtvXEqhOdlD85wwVy8Oql/cp9QgK5Efi58qSbO0itMyUtfTTHM1pIFcyNSYTnFs+Pp8Bs369Gef+xdzmTAfw/O8G3q475cad8wt5nI+VKF8Trl6JD/Y2q07Kri9TdsgwY9Urp6bkA+uGlwSMXnHFWV8jKQxRCL4DFCfIieoiJZGWBI2VZsAoGsuN/6PZixwrRG/BzhwrgJemGqcDorO0PRH6SY1fn4HtvQ5Sz+IDMypz1dZ/uR9epIh0rLlDi3N67eGwUdc5RuJB1u2BoiY4g0ENp0xdbl267bW1f6j3Dh+2nYKv0jeGI2MSs6+rHuN6r5Em28Csiyi5A==
	
#EncryptionKey: (EIisPENSreplacement!)
	euVKaZZh+9AYySqsahVdl5kxgZt2wFv6T7NoSkO/BDesVRQUyowpU2GOMLXMJrQq38zdI9G0OMMWWYgeFtDfnFuPHLazT0ve03MOmYTIiLhrjW7F1oQ9ABsy243xFcBOjX46uA54PLjyo+on6elk81CzugNjDVJvulfbANhGy3EmY5/RfJ+3cONLGavxwKobcc/qnmpy7XTYC5N9VGlnY81RlmzM5CtGlq9iZELKI0koBXOzwQJujTGoasHt8rOfJaePq5yf8Hq1DXIpG8/S9FvTtgoKxRwWhpw8JQDxY6//MFMwvq0hK/d3VOFaWn+vHyNqeWdJdHy+QtX5/sauRg==
	
AFNS:
------
1. Read contents from 'EnterpriseAccountSubsidiary' Xml file
2. Get all files #f1 from Current drop location
3. Get properties of files #f1 like 'Name', 'Size', 'LastModifiedDate' & 'DropLocation' at time 't1'
4. Wait for 'n' minutes
5. Get properties of files #f1 like 'Name', 'Size', 'LastModifiedDate' & 'DropLocation' at time 't2'
6. Compare and narrow down the list of files which are complete #f2
7. Compute the hash of those fields we captured, 'Name|Size|LastModifiedDate|DropLocation' as 32-bytes character long hash string
8. Forward these details to supervisor database. Check if this hash exists in database or not.
	8.1 If there is no match, insert as new request in 'dbo.RequestQueue'
	8.2 If it matches, ignore
9. Forward these details to azure queue
	9.1 If db insert happens, insert new message into respective queue
	9.2 Else, ignore
10. Forward the file to azure blob
	10.1 Insert the file into blob if it is small
	10.2 Fallback to AFNS

Resubmit tool (File-based requests):
-------------------------------------
1. Identify the list of failed requests by Sql query
2. Ops team select the failed requests and forward them from re-submit tool
3. Find the file (aes) from archives, decrypt the files and move to target drop location
4. Use InterchangeApi.SendFileNotifier() to forward this failed request to Email Interchange
	4.1 At this point, we have
		- Failed RequestID
		- ,...
		- Failed other parameters
	4.2 Modify 'sp_CreateRequest' for the following,
		- If RequestID does not exists, insert new entry to 'RequestQueue' table
		- If RequestID exists, update the properties like, 'IsProcessing: 0' & 'IsFailedState: 0'
	4.3 Always insert new message for this request
5. That's it! There is no duplicate request.