-- ====================================================================
 -- Author: ASIS
 -- Modified date: 2013-05-30
-- Description:    Stored Procedure to reserve the list of bgtsurrogateids 
 -- for jobs from various client feeds or from various countries.
 -- ====================================================================
 ALTER PROC [dbo].[bgtsurrogateidreserver] @noOfRowsToBeReserved INT
     ,@requestFrom VARCHAR(20)
     ,@startID BIGINT OUTPUT
     WITH RECOMPILE
 AS

 BEGIN TRANSACTION
 ---- SET NOCOUNT ON added to prevent extra result sets from
 ---- interfering with SELECT statements.
 SET NOCOUNT ON;
 DECLARE @res INT

 EXEC @res = sp_getapplock @Resource = 'reserve_bgtjobid_x_lock'
     ,@LockMode = 'Exclusive'
     ,@LockOwner = 'Transaction'
     ,@LockTimeout = 60000
     ,@DbPrincipal = 'public'

 --..ENABLE FOLLOWING STATEMENT ONLY IF YOU ARE DEBUGGING MODE..
 --PRINT 'LOCK(reserve_bgtjobid_x_lock) ACQUIRED: start reserving bgtjobids..'
 -- 0 and 1 are valid return values
 IF @res NOT IN (0, 1)
 BEGIN
     RAISERROR ('Unable to acquire Lock on reserve(reserve_bgtjobid_x_lock)', 16, 1)
 END
 ELSE
 BEGIN
     --CRITICAL REGION STARTS HERE..
     DECLARE @counter AS INT;

     SET @counter = 1;

     SELECT @startID = MAX(BGTJobId)
     FROM dbo.[TrackId] WITH (NOLOCK);

     WHILE @counter <= @noOfRowsToBeReserved
     BEGIN
         --Insert '#@noOfRowsToBeReserved' number of rows to reserve the 'bgtJobId'
         --Rows will have details,
         -- BgtJobId[AUTOINCREMENT], RequestFrom,UpdateTime
         --Later, we will merge or update fields VendorJobId,VendorName,            --Country at flatfileuploader level..
         INSERT INTO dbo.[TrackId] (
             RequestFrom
             ,UpdateTime
             ,VendorName
             )
         VALUES (
             @requestFrom
             ,GETDATE()
             ,''
             )

         --Increment @counter by 1
         SET @counter = @counter + 1;
     END

     --release exclusive lock on the resource, TrackId            
     EXEC @res = sp_releaseapplock @Resource = 'reserve_bgtjobid_x_lock'
         ,@DbPrincipal = 'public'
         ,@LockOwner = 'Transaction'
         --..ENABLE FOLLOWING STATEMENT ONLY IF YOU ARE DEBUGGING MODE..
         --PRINT 'LOCK(reserve_bgtjobid_x_lock) RELEASED: end reserving bgtjobids..'
 END
 COMMIT TRANSACTION