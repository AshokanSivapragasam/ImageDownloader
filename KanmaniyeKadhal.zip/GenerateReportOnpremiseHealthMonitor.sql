DECLARE @emailMessage NVARCHAR(MAX) = '
<html>
	<head>
		<style>
			body { font-family: Segoe UI; font-size: 0.8em}
			table { font-family: Segoe UI; border: solid 2px teal; border-collapse: collapse; font-size: 0.83em}
			th { border: 1px solid black; text-align: left}
			td { border: 1px solid black; }
			.text-ellipsis { max-width:300px; white-space: wrap; overflow:hidden;}
			table tr.header { background: #02add3; color: #FEFAFE; align: left}
			table tr.header td { text-transform: uppercase; font-weight: bold; }
			.DiscrepanciesWithinThreshold { background: #9DE69D}
			.DiscrepanciesAboveThreshold { background: #FF8D8D}
		</style>
	</head>
	<body>
Hi Support,<br/>
<br/>
Please act on it on top priority!! This ticket is from Email Interchange Application. EIOPS@microsoft.com will be primary (Tier3) contact to address this case.<br/>
<br/>
<table style=''font-family: Segoe UI''>
	<tr class=''header''><td colspan=''3'' align=''center''>Reports</td></tr>
	<tr class=''header''><td align=''center''>Scenario</td><td align=''center''>category</td><td align=''center''>Notes</td></tr>
	<tr><td>#1</td><td>Incoming Tbn Requests</td><td>[IncomingTbnRequestsNotes]</td></tr>
	
	<tr><td rowspan=''3''>#2</td><td colspan=''2''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Any request is in ''Failed'' or ''Inprogress'' state for more than 2 hours</td></tr>
	<tr><td>SubscriptionData Request</td><td>[NotCompletedAfterLongTimeSubscriptionDataRequestNotes]</td></tr>
	<tr><td>CustomerRefreshData Request</td><td>[NotCompletedAfterLongTimeCustomerRefreshDataRequestNotes]</td></tr>

	<tr><td rowspan=''3''>#3</td><td colspan=''2''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Incoming Sfmc Initiated Requests available or polled in last 2 hours</td></tr>
	<tr><td>SubscriptionData Request</td><td>[EtInitSubscriptionDataRequestNotes]</td></tr>
	<tr><td>CustomerRefreshData Request</td><td>[EtInitCustomerRefreshDataRequestNotes]</td></tr>

	<tr><td rowspan=''3''>#4</td><td colspan=''2''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Incoming EI Scheduled Requests available or polled in last 1 day</td></tr>
	<tr><td>DeleteSubscription Request</td><td>[EiSchDeleteSubscriptionRequestNotes]</td></tr>
	<tr><td>WizardData Request</td><td>[EiSchWizardDataRequestNotes]</td></tr>
</table>
<br/><br/>	
[RequestCountBreakdown]
<br/>
</body>
</html>';


DECLARE @tempText NVARCHAR(MAX);
/*
WITH cte AS (
    SELECT *, ROW_NUMBER() 
    over (
        PARTITION BY [Application], MachineName 
        order by RequestDateTime desc
    ) AS RowNo 
    FROM TransactionalLog with (nolock)
	Where MessageType = 'Exception'
	AND RequestDateTime BETWEEN dateadd(day, -1, getutcdate()) AND getutcdate()
)
SELECT @tempText =
(SELECT 
RowNo [tdc]
,LTRIM(RTRIM(EIRequestID)) [tdc]
,LTRIM(RTRIM(ETRequestID)) [tdc]
,LTRIM(RTRIM([Application])) [tdc]
,LTRIM(RTRIM(EventID)) [tdc]
,LTRIM(RTRIM([Event])) [td]
,LTRIM(RTRIM(MessageType)) [tdc]
,substring(isnull(MessageString, ''),0,400) + '...' [tdte]
,substring(isnull(StackString, ''),0,400) + '...' [tdte]
,LTRIM(RTRIM(RequestDateTime)) [tdnw]
,LTRIM(RTRIM(MachineName)) [tdnw]
 FROM cte WHERE RowNo <= 10
order by RequestDateTime desc, MachineName
FOR XML RAW('tr')
	,ELEMENTS)

SET @tempText = N'<table style=''font-family: Segoe UI''><tr class=''header''>
				<td>RowNo</td>
				<td>EiRequestId</td>
				<td>EtRequestId</td>
				<td>Application</td>
				<td>EventId</td>
				<td>Event</td>
				<td>MessageType</td>
				<td>MessageString</td>
				<td>StackString</td>
				<td>RequestDateTime</td>
				<td>MachineName</td>
			</tr>' + REPLACE(REPLACE(@tempText, '<tdc>', '<td align=''center'' style=''white-space: nowrap;''>'), '</tdc>', '</td>') + '</table>'
			
SET @tempText = REPLACE(REPLACE(@tempText, '<tdte>', '<td class=''text-ellipsis''>'), '</tdte>', '</td>')
SET @tempText = REPLACE(REPLACE(@tempText, '<tdnw>', '<td style=''white-space: nowrap;''>'), '</tdnw>', '</td>')
--SELECT convert(xml,@tempText);

SET @emailMessage = REPLACE(@emailMessage, '[LogsSection]', @tempText)
*/

SELECT @tempText = 
(select 
convert(date, requeststartdatetime) tdc
, RequestType  tdc
, (case when RequestStatus in ('Completed', 'Failed', 'InProgress') then RequestStatus else 'Unknown' end) tdc
, count(1) tdc
from vwrequest with (nolock)
where requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()
group by convert(date, requeststartdatetime), RequestType, RequestStatus
FOR XML RAW('tr')
	,ELEMENTS);

SET @tempText = REPLACE(REPLACE(REPLACE(REPLACE(@tempText, '<tdc>Completed</tdc>', '<td align=''center'' class=''DiscrepanciesWithinThreshold''>Completed</td>')
						, '<tdc>Failed</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>Failed</td>')
						, '<tdc>InProgress</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>InProgress</td>')
						, '<tdc>Unknown</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>Unknown</td>')

SET @tempText = N'<table style=''font-family: Segoe UI''><tr class=''header''>
				<td align=''center''>RequestStartDatetime</td>
				<td align=''center''>RequestType</td>
				<td align=''center''>RequestStatus</td>
				<td align=''center''>Count</td>
			</tr>' + REPLACE(REPLACE(@tempText, '<tdc>', '<td align=''center'' style=''white-space: nowrap;''>'), '</tdc>', '</td>') + '</table>'

SET @emailMessage = REPLACE(@emailMessage, '[RequestCountBreakdown]', @tempText)

SET @emailMessage = REPLACE(@emailMessage, '<td>[IncomingTbnrequestsNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>Tbn requests are fine</td>' else '<td class=''DiscrepanciesAboveThreshold''>No recent tbn requests</td>' end
						from vwrequest with (nolock)
						where requesttype = 'tbndata'
						and requeststartdatetime BETWEEN DATEADD(minute, -10, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[NotCompletedAfterLongTimeSubscriptionDataRequestNotes]</td>', (select case when count(*) = 0 then '<td class=''DiscrepanciesWithinThreshold''>No request is in progress' else '<td class=''DiscrepanciesAboveThreshold''>Some request(s) not completed after a long time' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'
						AND (case 
							when Requeststatus = 'Completed' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then 'NoAction'
							when datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 'NotCompletedAfterLongTime'
							else 'NotCompletedAfterLongTime' end) = 'NotCompletedAfterLongTime') + (select case when count(*) = 0 then ' | No request failed</td>' else ' | Some request(s) failed</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'
						AND (case 
							when Requeststatus <> 'Completed' then 'NotCompletedAfterLongTime'
							else 'NoAction' end) = 'NotCompletedAfterLongTime'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[NotCompletedAfterLongTimeCustomerRefreshDataRequestNotes]</td>', (select case when count(*) = 0 then '<td class=''DiscrepanciesWithinThreshold''>No request is in progress' else '<td class=''DiscrepanciesAboveThreshold''>Some request(s) not completed after a long time' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'
						AND (case 
							when Requeststatus = 'Completed' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then 'NoAction'
							when datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 'NotCompletedAfterLongTime'
							else 'NotCompletedAfterLongTime' end) = 'NotCompletedAfterLongTime') + (select case when count(*) = 0 then ' | No request failed</td>' else ' | Some request(s) failed</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'
						AND (case 
							when Requeststatus <> 'Completed' then 'NotCompletedAfterLongTime'
							else 'NoAction' end) = 'NotCompletedAfterLongTime'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EtInitSubscriptionDataRequestNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>SubscriptionData requests are fine</td>' else '<td class=''DiscrepanciesAboveThreshold''>SubscriptionData Request(s) not available</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(HOUR, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EtInitCustomerRefreshDataRequestNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>CustomerRefreshData requests are fine</td>' else '<td class=''DiscrepanciesAboveThreshold''>CustomerRefreshData request(s) not available</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EiSchDeleteSubscriptionRequestNotes]</td>', (select case when count(1) = 1 then '<td class=''DiscrepanciesWithinThreshold''>DeleteSubscription Request is available</td>' else '<td class=''DiscrepanciesAboveThreshold''>No DeleteSubscription Request is available</td>' end 
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(hour, -25, GETUTCDATE()) AND GETUTCDATE()
						and requesttype = 'DeleteSubscription'
						and RequestStatus = 'Completed'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EiSchWizardDataRequestNotes]</td>', (select case when count(1) = 1 then '<td class=''DiscrepanciesWithinThreshold''>WizardData Request is available</td>' else '<td class=''DiscrepanciesAboveThreshold''>No WizardData Request is available</td>' end 
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(hour, -25, GETUTCDATE()) AND GETUTCDATE()
						and requesttype = 'WizardData'
						and RequestStatus = 'Completed'))

SELECT convert(xml,@emailMessage);

