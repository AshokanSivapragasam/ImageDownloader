DECLARE @emailMessage NVARCHAR(MAX) = '
<html>
	<head>
		<style>
			body { font-family: Segoe UI; font-size: 0.8em}
			table { font-family: Segoe UI; border: solid 2px teal; border-collapse: collapse; font-size: 0.83em}
			th { border: 1px solid black; text-align: left}
			td { border: 1px solid black; }
			.text-ellipsis { max-width:300px; white-space: wrap; overflow:hidden;}
			table tr.header { background: #02add3; color: #FEFAFE; align: left}
			table tr.header td { text-transform: uppercase; font-weight: bold; }
			.DiscrepanciesWithinThreshold { background: #9DE69D}
			.DiscrepanciesAboveThreshold { background: #FF8D8D}
		</style>
	</head>
	<body>
Hi Support,<br/>
<br/>
Please act on it on top priority!! This ticket is from Email Interchange Application. EIOPS@microsoft.com will be primary (Tier3) contact to address this case.<br/>
<br/>
<table style=''font-family: Segoe UI''>
	<tr class=''header''><td colspan=''4'' align=''center''>Reports</td></tr>
	<tr class=''header''><td align=''center''>Scenario</td><td align=''center''>category</td><td align=''center''>Notes</td><td align=''center''>Action</td></tr>
	<tr><td>#1</td><td>Incoming Tbn Requests</td><td>[IncomingTbnRequestsNotes]</td></tr>
	
	<tr><td rowspan=''3''>#2</td><td colspan=''3''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Any request is in ''Failed'' or ''Inprogress'' state for more than 2 hours</td></tr>
	<tr><td>SubscriptionData Request</td><td>[NotCompletedAfterLongTimeSubscriptionDataRequestNotes]</td></tr>
	<tr><td>CustomerRefreshData Request</td><td>[NotCompletedAfterLongTimeCustomerRefreshDataRequestNotes]</td></tr>

	<tr><td rowspan=''3''>#3</td><td colspan=''3''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Incoming Sfmc Initiated Requests available or polled in last 2 hours</td></tr>
	<tr><td>SubscriptionData Request</td><td>[EtInitSubscriptionDataRequestNotes]</td></tr>
	<tr><td>CustomerRefreshData Request</td><td>[EtInitCustomerRefreshDataRequestNotes]</td></tr>

	<tr><td rowspan=''3''>#4</td><td colspan=''3''  align=''center'' style=''font-weight: bold; text-transform: uppercase''>Incoming EI Scheduled Requests available or polled in last 1 day</td></tr>
	<tr><td>DeleteSubscription Request</td><td>[EiSchDeleteSubscriptionRequestNotes]</td></tr>
	<tr><td>WizardData Request</td><td>[EiSchWizardDataRequestNotes]</td></tr>
</table>
<br/><br/>	
[RequestCountBreakdown]
<br/>

<table style="font-family: Segoe UI;"><tbody><tr class="header"><td align="center" colspan="3">Service whereabouts</td></tr><tr class="header"><td align="center">MachineId</td><td align="center">MachineName</td><td align="center">Services Installed</td></tr><tr><td>#1</td><td>BY2MSFTVWBEI51.phx.gbl</td><td>LogWriter, ExecutionEngine, MSIConnectorHost, PollEngine, EIPullServiceHost</td></tr><tr><td>#2</td><td>BY2MSFTVAPIEI51.phx.gbl</td><td>LogWriter, RequestStore, EIPullServiceHost, GenesisAdapter</td></tr><tr><td>#3</td><td>BY2MSFTVASEI51.portal.gbl</td><td>LogWriter, RequestScheduler, RequestStore</td></tr><tr><td>#4</td><td>BY2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr><tr><td>#5</td><td>CO2MSFTVWBEI51.phx.gbl</td><td>LogWriter, ExecutionEngine, MSIConnectorHost, PollEngine, EIPullServiceHost</td></tr><tr><td>#6</td><td>CO2MSFTVAPIEI51.phx.gbl</td><td>LogWriter, RequestStore, EIPullServiceHost, GenesisAdapter</td></tr><tr><td>#7</td><td>CO2MSFTVASEI51.portal.gbl</td><td>LogWriter, RequestScheduler, RequestStore</td></tr><tr><td>#8</td><td>CO2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr></tbody></table>

</body>
</html>';


DECLARE @tempText NVARCHAR(MAX);

SELECT @tempText = 
(select 
convert(date, requeststartdatetime) tdc
, RequestType  tdc
, (case when RequestStatus in ('Completed', 'Failed', 'InProgress', 'BetweenRetries') then RequestStatus else 'Unknown' end) tdc
, count(1) tdc
from vwrequest with (nolock)
where requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()
group by convert(date, requeststartdatetime), RequestType, RequestStatus
FOR XML RAW('tr')
	,ELEMENTS);

SET @tempText = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@tempText, '<tdc>Completed</tdc>', '<td align=''center'' class=''DiscrepanciesWithinThreshold''>Completed</td>')
						, '<tdc>Failed</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>Failed</td>')
						, '<tdc>InProgress</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>InProgress</td>')
						, '<tdc>BetweenRetries</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>BetweenRetries</td>')
						, '<tdc>Unknown</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>Unknown</td>')

SET @tempText = N'<table style=''font-family: Segoe UI''><tr class="header"><td align="center" colspan="4"> Request Count Breakdown</td></tr>
				<tr class=''header''>
				<td align=''center''>RequestStartDatetime</td>
				<td align=''center''>RequestType</td>
				<td align=''center''>RequestStatus</td>
				<td align=''center''>Count</td>
			</tr>' + REPLACE(REPLACE(@tempText, '<tdc>', '<td align=''center'' style=''white-space: nowrap;''>'), '</tdc>', '</td>') + '</table>'

SET @emailMessage = REPLACE(@emailMessage, '[RequestCountBreakdown]', @tempText)

SET @emailMessage = REPLACE(@emailMessage, '<td>[IncomingTbnrequestsNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>Tbn requests are fine</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else '<td class=''DiscrepanciesAboveThreshold''>No recent tbn requests</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end
						from vwrequest with (nolock)
						where requesttype = 'tbndata'
						and requeststartdatetime BETWEEN DATEADD(minute, -10, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[NotCompletedAfterLongTimeSubscriptionDataRequestNotes]</td>', (select case when count(*) = 0 then '<td class=''DiscrepanciesWithinThreshold''>No request is in progress' else '<td class=''DiscrepanciesAboveThreshold''>Some request(s) not completed after a long time' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'
						AND (case 
							when Requeststatus = 'Completed' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then 'NoAction'
							when datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 'NotCompletedAfterLongTime'
							else 'NotCompletedAfterLongTime' end) = 'NotCompletedAfterLongTime') + (select case when count(*) = 0 then ' | No request failed</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else ' | Some request(s) failed</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'
						AND (case 
							when Requeststatus <> 'Completed' then 'NotCompletedAfterLongTime'
							else 'NoAction' end) = 'NotCompletedAfterLongTime'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[NotCompletedAfterLongTimeCustomerRefreshDataRequestNotes]</td>', (select case when count(*) = 0 then '<td class=''DiscrepanciesWithinThreshold''>No request is in progress' else '<td class=''DiscrepanciesAboveThreshold''>Some request(s) not completed after a long time' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'
						AND (case 
							when Requeststatus = 'Completed' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then 'NoAction'
							when datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 'NotCompletedAfterLongTime'
							else 'NotCompletedAfterLongTime' end) = 'NotCompletedAfterLongTime') + (select case when count(*) = 0 then ' | No request failed</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else ' | Some request(s) failed</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'
						AND (case 
							when Requeststatus <> 'Completed' then 'NotCompletedAfterLongTime'
							else 'NoAction' end) = 'NotCompletedAfterLongTime'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EtInitSubscriptionDataRequestNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>SubscriptionData requests are fine</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else '<td class=''DiscrepanciesAboveThreshold''>SubscriptionData Request(s) not available</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(HOUR, -2, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'SubscriptionData'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EtInitCustomerRefreshDataRequestNotes]</td>', (select case when count(*) > 0 then '<td class=''DiscrepanciesWithinThreshold''>CustomerRefreshData requests are fine</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else '<td class=''DiscrepanciesAboveThreshold''>CustomerRefreshData request(s) not available</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(DAY, -1, GETUTCDATE()) AND GETUTCDATE()
						AND requesttype = 'CustomerRefreshData'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EiSchDeleteSubscriptionRequestNotes]</td>', (select case when count(1) = 1 then '<td class=''DiscrepanciesWithinThreshold''>DeleteSubscription Request is available</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else '<td class=''DiscrepanciesAboveThreshold''>No DeleteSubscription Request is available</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end 
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(hour, -25, GETUTCDATE()) AND GETUTCDATE()
						and requesttype = 'DeleteSubscription'
						and RequestStatus = 'Completed'))

SET @emailMessage = REPLACE(@emailMessage, '<td>[EiSchWizardDataRequestNotes]</td>', (select case when count(1) = 1 then '<td class=''DiscrepanciesWithinThreshold''>WizardData Request is available</td><td class="DiscrepanciesWithinThreshold">No action required</td>' else '<td class=''DiscrepanciesAboveThreshold''>No WizardData Request is available</td><td class="DiscrepanciesAboveThreshold">1. Check health of all windows services<br/>
					2. See if we have any exceptions in event viewer<br/>
					3. Report this incident to T3 if it is not solvable</td>' end 
						from vwrequest with (nolock)
						where requeststartdatetime BETWEEN DATEADD(hour, -25, GETUTCDATE()) AND GETUTCDATE()
						and requesttype = 'WizardData'
						and RequestStatus = 'Completed'))

SELECT convert(xml,@emailMessage);

