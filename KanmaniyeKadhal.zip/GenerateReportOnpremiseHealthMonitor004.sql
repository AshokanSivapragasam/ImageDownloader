DECLARE @emailMessage NVARCHAR(MAX) = '
<html>
	<head>
		<style>
			body { font-family: Segoe UI; font-size: 0.8em}
			table { font-family: Segoe UI; border: solid 2px teal; border-collapse: collapse; font-size: 0.83em}
			th { border: 1px solid black; text-align: left}
			td { border: 1px solid black; }
			.text-ellipsis { max-width:300px; white-space: wrap; overflow:hidden;}
			table tr.header { background: #02add3; color: #FEFAFE; align: left}
			table tr.header td { text-transform: uppercase; font-weight: bold; }
			.DiscrepanciesWithinThreshold { background: #5FBA7D; color: WHITE;}
			.DiscrepanciesAboveThreshold { background: #FF8D8D; color: WHITE;}
			.DiscrepanciesWarningThreshold { background: #FFD200; color: BROWN;}
		</style>
	</head>
	<body>
Hi Support,<br/>
<br/>
Please act on it on top priority!! This ticket is from Email Interchange Application. EIOPS@microsoft.com will be primary (Tier3) contact to address this case.<br/>
<br/>
<table style=''font-family: Segoe UI''>
	<tr class=''header''>
		<td colspan=''4'' align=''center''>Reports</td>
	</tr>
	<tr class=''header''>
		<td align=''center''>Scenario</td>
		<td align=''center''>category</td>
		<td align=''center''>Notes</td>
		<td align=''center''>Action</td>
	</tr>
	<tr>
		<td>#1</td>
		<td>TbnData</td>
		<td>[TbnRequestReport]</td>
	</tr>
	<tr>
		<td>#2</td>
		<td>DeleteSubscription</td>
		<td>[DeleteSubscriptionReport]</td>
	</tr>
	<tr>
		<td>#3</td>
		<td>WizardData</td>
		<td>[WizardDataReport]</td>
	</tr>
	<tr>
		<td>#4</td>
		<td>SubscriptionData</td>
		<td>[SubscriptionDataReport]</td>
	</tr>
	<tr>
		<td>#5</td>
		<td>CustomerRefreshData</td>
		<td>[CustomerRefreshDataReport]</td>
	</tr>
</table>
<br/><br/>	
[RequestCountBreakdown]
<br/>

<table style="font-family: Segoe UI;"><tbody><tr class="header"><td align="center" colspan="3">Service whereabouts</td></tr><tr class="header"><td align="center">MachineId</td><td align="center">MachineName</td><td align="center">Services Installed</td></tr><tr><td>#1</td><td>BY2MSFTVWBEI51.phx.gbl</td><td>LogWriter, ExecutionEngine, MSIConnectorHost, PollEngine, EIPullServiceHost</td></tr><tr><td>#2</td><td>BY2MSFTVAPIEI51.phx.gbl</td><td>LogWriter, RequestStore, EIPullServiceHost, GenesisAdapter</td></tr><tr><td>#3</td><td>BY2MSFTVASEI51.portal.gbl</td><td>LogWriter, RequestScheduler, RequestStore</td></tr><tr><td>#4</td><td>BY2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr><tr><td>#5</td><td>CO2MSFTVWBEI51.phx.gbl</td><td>LogWriter, ExecutionEngine, MSIConnectorHost, PollEngine, EIPullServiceHost</td></tr><tr><td>#6</td><td>CO2MSFTVAPIEI51.phx.gbl</td><td>LogWriter, RequestStore, EIPullServiceHost, GenesisAdapter</td></tr><tr><td>#7</td><td>CO2MSFTVASEI51.portal.gbl</td><td>LogWriter, RequestScheduler, RequestStore</td></tr>
<tr><td>#8</td><td>CO2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr>
<tr><td>#9</td><td>AZBY2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr>
<tr><td>#10</td><td>AZCO2MSFTVCEI51</td><td>LogWriter, ExecutionEngine</td></tr></tbody></table>
<br/><br/>
Thanks,<br/>
Ei Automation<br/>
</body>
</html>';


DECLARE @tempText NVARCHAR(MAX);

SELECT @tempText = 
(select 
convert(date, requeststartdatetime) tdc
, RequestType  tdc
, (case when RequestStatus in ('Completed', 'Failed', 'InProgress', 'BetweenRetries') then RequestStatus else 'Unknown' end) tdc
, count(1) tdc
from vwrequest with (nolock)
where requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()
group by convert(date, requeststartdatetime), RequestType, RequestStatus
order by convert(date, requeststartdatetime) desc
FOR XML RAW('tr')
	,ELEMENTS);

SET @tempText = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@tempText, '<tdc>Completed</tdc>', '<td align=''center'' class=''DiscrepanciesWithinThreshold''>Completed</td>')
						, '<tdc>Failed</tdc>', '<td align=''center'' class=''DiscrepanciesAboveThreshold''>Failed</td>')
						, '<tdc>InProgress</tdc>', '<td align=''center'' class=''DiscrepanciesWarningThreshold''>InProgress</td>')
						, '<tdc>BetweenRetries</tdc>', '<td align=''center'' class=''DiscrepanciesWarningThreshold''>BetweenRetries</td>')
						, '<tdc>Unknown</tdc>', '<td align=''center'' class=''DiscrepanciesWarningThreshold''>Unknown</td>')

SET @tempText = N'<table style=''font-family: Segoe UI''><tr class="header"><td align="center" colspan="4"> Request Count Breakdown</td></tr>
				<tr class=''header''>
				<td align=''center''>RequestStartDatetime</td>
				<td align=''center''>RequestType</td>
				<td align=''center''>RequestStatus</td>
				<td align=''center''>Count</td>
			</tr>' + REPLACE(REPLACE(@tempText, '<tdc>', '<td align=''center'' style=''white-space: nowrap;''>'), '</tdc>', '</td>') + '</table>'

SET @emailMessage = REPLACE(@emailMessage, '[RequestCountBreakdown]', @tempText)

SET @emailMessage = REPLACE(@emailMessage, '<td>[TbnRequestReport]</td>', (select 
							'<td>' + (case when count(1) = 0 then 'No requests available<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 20 then 'Over 20 Tbns failed<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(minute, requeststartdatetime, getutcdate()) >= 30 then 1 else 0 end) > 20 then 'Over 20 Tbns are in progress for >30 minutes' else '' end
							+case when count(1) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) <= 20 and
							sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(minute, requeststartdatetime, getutcdate()) >= 30 then 1 else 0 end) <= 20 then 'Everything is fine' else '' end) + '</td>'

							+ '<td>' + (case when count(1) = 0 then 'Check the health of all on-premise services; start those if not disabled<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 20 then 'Verify the transactional & system logs for any exceptions for failed requests<br/>Resolve it if it is critical' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(minute, requeststartdatetime, getutcdate()) >= 30 then 1 else 0 end) > 20 then 'Sql server might have intermittent problems. Check logs and act as appropriate' else '' end
							+case when count(1) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) <= 20 and
							sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(minute, requeststartdatetime, getutcdate()) >= 30 then 1 else 0 end) <= 20 then 'No action required' else '' end) + '</td>'

							from vwrequest with (nolock)
							where requesttype = 'tbndata'
							and requeststartdatetime BETWEEN DATEADD(minute, -30, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[DeleteSubscriptionReport]</td>', (select 
							'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'One or more DeleteSubscription requests failed in last 24 hours<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'One or more DeleteSubscription requests are in progress for 4+ hours' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) >= 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'Everything is fine' else '' end) + '</td>'

							+'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'Check the health of on-premise services like Request Store (Portal), RequestScheduler (Portal.gbl), Execution Engine (Corpnet); restart those if not disabled.' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'Verify the transactional &amp; system logs for any exceptions for failed requests<br/>Resolve it if it is critical.<br/><br/>Reschedule the request as soon as you see it is failed due to intermittent reasons.<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'Sql server might have intermittent problems. Check logs and act as appropriate.<br/>It is usual that sometimes Delete Subscription Request is taking long time.<br/>But it is inevitable to follow the logs to capture any issues (if any) at the earliest.' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) >= 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'No action required' else '' end) + '</td>'

							from vwrequest with (nolock)
							where requesttype = 'deletesubscription'
							and requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[WizardDataReport]</td>', (select 
							'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'One or more Wizard Data requests failed in last 24 hours<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'One or more Wizard Data requests are in progress for 4+ hours' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'One or more Wizard Data requests are waiting for Execution Engine in Corpnet' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) >= 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'Everything is fine' else '' end) + '</td>'

							+'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'Check the health of on-premise services like Request Store (Portal), RequestScheduler (Portal.gbl), Execution Engine (Corpnet); restart those if not disabled.' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'Verify the transactional &amp; system logs for any exceptions for failed requests<br/>Resolve it if it is critical.<br/><br/>Reschedule the request as soon as you see it is failed due to intermittent reasons.<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'Sql server might have intermittent problems. Check logs and act as appropriate.<br/>It is usual that sometimes Wizard Data  Request is taking long time.<br/>But it is inevitable to follow the logs to capture any issues (if any) at the earliest.' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'Execution Engine (Corpnet) might have stopped or gone unresponsive.<br/>Restart the services if not disabled in Corpnet Server.<br/>' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) >= 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'No action required' else '' end) + '</td>'

							from vwrequest with (nolock)
							where requesttype = 'WizardData'
							and requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[SubscriptionDataReport]</td>', (select 
							'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'One or more Subscription Data requests failed in last 24 hours<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more Subscription Data requests are in progress for 4+ hours' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'One or more Subscription Data requests are waiting for Execution Engine in Corpnet' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 2 then 1 else 0 end) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 2) then 1 else 0 end) = 0 then 'Everything is fine' else '' end) + '</td>'

							+ '<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 2 then 1 else 0 end) = 0 then 'Check the health of all on-premise services; start those if not disabled<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'Verify the transactional &amp; system logs for any exceptions for failed requests<br/>Resolve it if it is critical' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Sql server might have intermittent problems. Check logs and act as appropriate' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) > 0 then 'Execution Engine (Corpnet) might have stopped or gone unresponsive.<br/>Restart the services if not disabled in Corpnet Server.<br/>' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 2 then 1 else 0 end) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 2) then 1 else 0 end) = 0 then 'No action required' else '' end) + '</td>'

							from vwrequest with (nolock)
							where requesttype = 'SubscriptionData'
							and requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()))

SET @emailMessage = REPLACE(@emailMessage, '<td>[CustomerRefreshDataReport]</td>', (select 
							'<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'No requests available<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'One or more CustomerRefresh Data requests failed in last 24 hours<br/>' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'One or more CustomerRefresh Data requests are in progress for 4+ hours' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'One or more CustomerRefresh Data requests are waiting for Execution Engine in Corpnet' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'Everything is fine' else '' end) + '</td>'

							+ '<td>' + (case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) = 0 then 'Check the health of all on-premise services; start those if not disabled<br/>' else '' end
							+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 0 then 'Verify the transactional &amp; system logs for any exceptions for failed requests<br/>Resolve it if it is critical' else '' end
							+case when sum(case when RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'Sql server might have intermittent problems. Check logs and act as appropriate' else '' end
							+case when sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) > 0 then 'Execution Engine (Corpnet) might have stopped or gone unresponsive.<br/>Restart the services if not disabled in Corpnet Server.<br/>' else '' end
							+case when sum(case when datediff(hour, requeststartdatetime, getutcdate()) <= 28 then 1 else 0 end) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) = 0 and
							sum(case when RequestStatus = 'Completed' and (CompressedFileSize = 0 or EncryptedFileSize = 0) and datediff(hour, requeststartdatetime, getutcdate()) >= 4 then 1 else 0 end) = 0 and
							sum(case when (RequestStatus in ('InProgress', 'BetweenRetries') and datediff(hour, requeststartdatetime, getutcdate()) >= 4) then 1 else 0 end) = 0 then 'No action required' else '' end) + '</td>'

							from vwrequest with (nolock)
							where requesttype = 'CustomerRefreshData'
							and requeststartdatetime BETWEEN DATEADD(day, -1, GETUTCDATE()) AND GETUTCDATE()))

SELECT convert(xml,@emailMessage) as [EmailMessage];

