-- Make a link to the cloud
EXEC sp_addlinkedserver   
   @server=N'ProdAzureSQLDB', 
   @srvproduct=N'Azure SQL Db',
   @provider=N'SQLNCLI', 
   @datasrc=N'eo7divp7as.database.windows.net,1433',
   @catalog='SubManDB';
GO

--Set up login mapping
EXEC sp_addlinkedsrvlogin 
    @rmtsrvname = 'ProdAzureSQLDB', 
    @useself = 'FALSE', 
    @locallogin=NULL,
    @rmtuser = 'SMProdReader',
    @rmtpassword = 'P@&&^0r#$786'
GO

-- Test the connection
sp_testlinkedserver ProdAzureSQLDB;