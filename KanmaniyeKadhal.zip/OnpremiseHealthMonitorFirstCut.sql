DECLARE @emailMessage NVARCHAR(MAX) = '
Hi Support,

Please act on it on top priority!! This ticket is from Email Interchange Application. EIOPS@microsoft.com will be primary (Tier3) contact to address this case.

Possible rules,
Scenario #1 - No incoming Tbn requests
				select case when count(*) > 0 then ''Tbn requests are fine'' else ''No recent tbn requests'' end
				from vwrequest with (nolock)
				where requesttype = ''tbndata''
				and requeststartdatetime BETWEEN DATEADD(minute, -10, GETUTCDATE()) AND GETUTCDATE()

Scenario #2 - Any request is in ''''Inprogress'''' for more than 2 hours
				select top 100 getutcdate(),(case 
					when RequestType <> ''DeleteSubscription'' and Requeststatus = ''completed'' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then ''NoAction''
					when RequestType <> ''DeleteSubscription'' and Requeststatus <> ''completed'' and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then ''NotCompletedAfterLongTime''
					when RequestType = ''DeleteSubscription'' and Requeststatus = ''completed'' then ''NoAction''
					else ''NotCompletedAfterLongTime'' end),* from vwrequest with (nolock)
				where requeststartdatetime BETWEEN DATEADD(day, -2, GETUTCDATE()) AND GETUTCDATE()
				and requesttype <> ''tbndata''
				and 
				(case 
					when RequestType <> ''DeleteSubscription'' and Requeststatus = ''completed'' and CompressedFileSize <> 0 and EncryptedFileSize <> 0 then ''NoAction''
					when RequestType <> ''DeleteSubscription'' and Requeststatus <> ''completed'' and datediff(hour, requeststartdatetime, getutcdate()) >= 2 then ''NotCompletedAfterLongTime''
					when RequestType = ''DeleteSubscription'' and Requeststatus = ''completed'' then ''NoAction''
					else ''NotCompletedAfterLongTime'' end	) <> ''NoAction'' 
				--and datediff(hour, requeststartdatetime, getutcdate()) >= 1
				order by requeststartdatetime desc
				
Scenario #3 - No EtInit request available or polled in last 2 hours | Latest exceptions are available for polling Engine
				select case when count(*) > 0 then ''EtInit Requests are available'' else ''No EtInit Request is available'' end from vwrequest with (nolock)
				where requeststartdatetime BETWEEN DATEADD(hour, -2, GETUTCDATE()) AND GETUTCDATE()
				and requesttype in (''SubscriptionData'', ''CustomerRefreshData'')
				
Scenario #4 - No EiSch request available after 1 hour, the scheduled time is fired
				select case when count(1) = 2 then ''EiSch Requests are available'' else ''No EiSch Request is available'' end 
				from vwrequest with (nolock)
				where requeststartdatetime BETWEEN DATEADD(hour, -25, GETUTCDATE()) AND GETUTCDATE()
				and requesttype in (''WizardData'', ''DeleteSubscription'')
				and RequestStatus = ''Completed''

Please follow the below steps to resolve,
1 - Stop InterchangeMsiFileProcessor in CO2...WBE.. Server
2 - Stop MSIConnectorWithNetPipe in CO2...WBE.. Server
3 - Run the following query in InterchangeDb database of Production server
            UPDATE MsiFileSupervisor
            SET ProcessingStatus = ''New'', NoOfIterations = 0
            WHERE ProcessingStatus in (''PermanentlyBlocked'', ''InProgress'')

4 - Start MSIConnectorWithNetPipe in CO2...WBE.. Server
5 - Start InterchangeMsiFileProcessor in CO2...WBE.. Server

By,
Sql Server Job
'


IF EXISTS(select top 1 * from msifilesupervisor with (nolock)
where ProcessingStatus = 'PermanentlyBlocked') OR EXISTS(select top 1 * from msifilesupervisor with (nolock)
where ProcessingStatus = 'Inprogress' and datediff(hour, FileProcessingStartDateTime, getutcdate()) > 2) OR NOT EXISTS(select top 1 * from msifilesupervisor with (nolock)
where datediff(hour, FileProcessingStartDateTime, getutcdate()) < 2)
print @emailMessage
ELSE
print 'No action'


select 
'<td>' + (case when count(1) = 0 then 'No requests available<br/>' else '' end
+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 10 then 'Over 10 Tbns failed<br/>' else '' end
+case when sum(case when RequestStatus = 'InProgress' and datediff(minute, requeststartdatetime, getutcdate()) >= 3 then 1 else 0 end) > 10 then 'Over 10 Tbns are in progress for >30 minutes' else '' end
+case when count(1) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) <= 10 and
sum(case when RequestStatus = 'InProgress' and datediff(minute, requeststartdatetime, getutcdate()) < 3 then 1 else 0 end) <= 10 then 'Everything is fine' else '' end) + '</td>'

+ '<td>' + (case when count(1) = 0 then 'Check the health of all on-premise services; start those if not disabled<br/>' else '' end
+case when sum(case when RequestStatus = 'failed' then 1 else 0 end) > 10 then 'Verify the transactional & system logs for any exceptions for failed requests<br/>Resolve it if it is critical' else '' end
+case when sum(case when RequestStatus = 'InProgress' and datediff(minute, requeststartdatetime, getutcdate()) >= 3 then 1 else 0 end) > 10 then 'Sql server might have intermittent problems. Check logs and act as appropriate' else '' end
+case when count(1) > 0 and sum(case when RequestStatus = 'failed' then 1 else 0 end) <= 10 and
sum(case when RequestStatus = 'InProgress' and datediff(minute, requeststartdatetime, getutcdate()) < 3 then 1 else 0 end) <= 10 then 'No action required' else '' end) + '</td>'

from vwrequest with (nolock)
where requesttype = 'tbndata'
and requeststartdatetime BETWEEN DATEADD(minute, -30, GETUTCDATE()) AND GETUTCDATE()