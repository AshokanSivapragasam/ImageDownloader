/*
   Task delagator
*/
declare @NameOfServiceToBeMonitored nvarchar(100) = 'AudioSrv'
select ServiceName, SqlScript, DbConnectionString
,ServerName, DomainName, Username, Password from OnpremiseServiceHealthByDatabase opshd
inner join DatabaseDetails dd on dd.Id = opshd.DatabaseId
inner join OnpremiseServers ops on ops.Id = opshd.ServerId
where opshd.ServiceName = @NameOfServiceToBeMonitored

/*
    Task Delegator
*/
declare @NameOfServiceToBeMonitored nvarchar(100) = 'AudioSrv'

select NameOfTask as '@NameOfTask'
, ServiceName as '@ServiceName'
, DbConnectionString as '@DbConnectionString'
, ServerName as '@ServerName'
, DomainName as '@DomainName'
, Username as '@Username'
, [Password] as '@Password'
, SqlScript as [HealthCheckerSqlQuery]
from OnpremiseHealthMonitorTaskQueue ophmtq
inner join OnpremiseServiceHealthByDatabase opshd on ophmtq.NameOfService = opshd.ServiceName
inner join DatabaseDetails dd on dd.Id = opshd.DatabaseId
inner join OnpremiseServers ops on ops.Id = opshd.ServerId
where opshd.ServiceName = @NameOfServiceToBeMonitored
FOR XML PATH('WorkItem'), ROOT('WorkItems')

/*
   Polling Engine
*/
select * from EntryPointService
where EntryPointServiceTypeID = 4
and ServiceAliveDateTime > dateadd(minute, -30, getutcdate())

ALTER PROCEDURE [dbo].[spLogAnalyzerPollingEngine]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT CASE WHEN COUNT(1) > 0 THEN 1 ELSE 0 END
    FROM   EntryPointService
    WHERE  EntryPointServiceTypeID = 4
           AND ServiceAliveDateTime > dateadd(minute, -30, getutcdate());
END


/*
   Execution Engine
*/
select MessageType, count(*) from transactionallog with (nolock)
where requestdatetime > dateadd(minute, -30, getutcdate())
and [Application] = 'ExecutionEngine'
group by MessageType

DROP TABLE #patterns 
CREATE TABLE #patterns (
  pattern VARCHAR(200)
);

INSERT INTO #patterns VALUES ('%untrusted domain%'), ('%replica role is RESOLVING%'), ('PQR%');
DECLARE @pattern varchar(200);

DECLARE cursorName CURSOR -- Declare cursor
LOCAL SCROLL STATIC
FOR 
Select pattern FROM #patterns

OPEN cursorName -- open the cursor
FETCH NEXT FROM cursorName
   INTO @pattern

WHILE @@FETCH_STATUS = 0
BEGIN
   PRINT @pattern -- print the name

	SELECT * FROM SystemLog with (nolock)
	where requestlogdatetime between 
	'2015-12-01 17:31:35.433' and getutcdate()
	and [Application] = 'ExecutionEngine'
	and messagetype = 'Exception'
	and MessageString LIKE @pattern
	order by requestlogdatetime asc

   FETCH NEXT FROM cursorName
   INTO @pattern
   
END

CLOSE cursorName -- close the cursor
DEALLOCATE cursorName -- Deallocate the cursor

Login failed. The login is from an untrusted domain and cannot be used with Windows authentication.
Cannot open database "EmailInterchange" requested by the login. The login failed. Login failed for user 'PHX\_eisql'.
Unable to access database 'EmailInterchange' because its replica role is RESOLVING which does not allow connections. Try the operation again later.

    SELECT   DISTINCT TOP 3 *
    FROM     SystemLog WITH (NOLOCK)
    WHERE    requestlogdatetime BETWEEN DATEADD(MINUTE, -30, GETUTCDATE()) AND GETUTCDATE()
             AND [Application] = 'PollingEngine'
             AND messagetype = 'Exception'
    ORDER BY requestlogdatetime ASC;






Communication create SM UI --> Genesis sp --> SM database
Communication update SM UI --> Genesis sp --> SM database
