--Drop all symmetric keys and certificates in this order

--Drop masterkey
DROP MASTER KEY;

--Restore masterkey from older backups
RESTORE MASTER KEY FROM FILE = 'D:\DbMasterKey\MasterKey'  DECRYPTION BY PASSWORD = '<<NewMasterKeyPassword>>' ENCRYPTION BY PASSWORD = '<<NewMasterKeyPassword>>' FORCE

--Create certificate
CREATE CERTIFICATE AzureArchiveCertificate 
   ENCRYPTION BY PASSWORD = '<<NewMasterKeyPassword>>'
   WITH SUBJECT = 'AzureArchiveCertificate', 
   EXPIRY_DATE = '20201031';
GO

-- Create symmetric key on top of certificate
CREATE SYMMETRIC KEY AzureArchiveKey 
WITH ALGORITHM = AES_256
ENCRYPTION BY CERTIFICATE AzureArchiveCertificate;
GO

-- Open the symmetric key with which to encrypt the data. 
OPEN SYMMETRIC KEY AzureArchiveKey 
DECRYPTION BY CERTIFICATE AzureArchiveCertificate with Password = '<<NewMasterKeyPassword>>'
SELECT CONVERT(nvarchar(500), DecryptByKey(EncryptByKey(Key_Guid('AzureArchiveKey'), ConfigurationValue))) FROM AzureArchiveConfiguration WHERE ConfigurationKey = 'SourceUserPassword' 
