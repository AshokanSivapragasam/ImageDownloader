EmailInterchangeApi	8408AAD6D255F618F1F76FF7CE10B27251376118
ExactTargetPreview	7DFA7130BEA951A4122A944AB2FC27FEBCEBF299
ExactTargetProdTest	080B7B902741B95AFD713B56A404DA5F96EE460A
ExactTargetProd_S1Stack	7C97571665383D0D8E868D24C5995281DF96B2FD
ExactTargetProd_S4Stack	38C8A2D6F86DF06DD3BFF4583C2EBB714E5C7D07
MDMCertificate	7291075F0563DDAA9B9FEEB5297DAB2A5F1063DF
MDMClientCertificate	69BBFF6DECE6953BD696FD0B827D65A5B0F29B9A
Microsoft.WindowsAzure.Plugins.RemoteAccess.PasswordEncryption	27A7F3DC52CE888BADB26112B45CA34463FDB3A0
MSICertificate	49C7737BBB0E470139B231729DCD9B697A61F9BF
SecretsCertificate	9FDE4FEFD15B9B3882933676BA6959B72198D1CD
Tenant01	D830B562F56E0E421358F978E8F7334D0D04B3B6


(New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("D:\Usr\Amit\LatestTempCertificates\CER\emailinterchangeapi-dev3.trafficmanager.net.cer")).Thumbprint

(New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\Users\v-assiva\Documents\Certificates\webservice.exacttarget.com.cer")).Thumbprint

(get-item cert:\LocalMachine\My\27A7F3DC52CE888BADB26112B45CA34463FDB3A0)

Set-AzureSubscription -SubscriptionName "mysub" -SubscriptionId "subscriptionid" -Certificate $cert

EmailInterchangeApi 8408AAD6D255F618F1F76FF7CE10B27251376118
ExactTargetPreview 7DFA7130BEA951A4122A944AB2FC27FEBCEBF299
ExactTargetProdTest 080B7B902741B95AFD713B56A404DA5F96EE460A
ExactTargetProd_S1Stack 7C97571665383D0D8E868D24C5995281DF96B2FD
ExactTargetProd_S4Stack 38C8A2D6F86DF06DD3BFF4583C2EBB714E5C7D07
MDMCertificate 7291075F0563DDAA9B9FEEB5297DAB2A5F1063DF
MDMClientCertificate 69BBFF6DECE6953BD696FD0B827D65A5B0F29B9A
Microsoft.WindowsAzure.Plugins.RemoteAccess.PasswordEncryption 27A7F3DC52CE888BADB26112B45CA34463FDB3A0
MSICertificate 49C7737BBB0E470139B231729DCD9B697A61F9BF
SecretsCertificate 1B647BE314FBC0E8ECCD885C3442A9E63C7EB5B5
Tenant01 D830B562F56E0E421358F978E8F7334D0D04B3B6


Total number of transition hours
	
Total number of KTs/reverse KTs conducted
Artefacts created – recordings, documents etc.
Total resources involved in KT
Transition best practices and key learnings


{"Could not establish trust relationship for the SSL/TLS secure channel with authority 'emailinterchangeapi-dev3.cloudapp.net'."}