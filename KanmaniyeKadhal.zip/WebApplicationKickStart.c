#03 Create a new MVC Proj
	1. Html5 (Doctype html) - [TICK]
	2. Html lang locale - [TICK]
	3. Html charset - [TICK]
	4. Html viewport (Mobile devices) - [TICK]
	5. Modernizer (Helps to adopt to old browsers if any new definition in our webpage) - [CHECK]
	6. Asp.net MVC 4 (Nuget introduced) - [CHECK]


#04 How MVC Works
	1. Model (Not database; just class and objects) - [TICK]
	2. View (Just to display something based on model data (if needed)) - [TICK]
	3. Controller (Create model object and redirect proper view; it can be defined on top of any data layer or web services) - [TICK]
	4. Embrace the web (Html5, Javascript, Css3) - [CHECK]
	5. Runs on top of Asp.net - [TICK]
	6. Extensible (Can plugin more extensions in case of enhancement\ security) - [CHECK]
	7. It allows all traditional web components - [TICK]
	8. It is perfectly testable - [CHECK]
	

#06 How to build MVC app II
	1. Url -> Web server (IIS Express or std) -> Asp.net mvc framework -> Crtl - [TICK]
	2. Routing api engine (Ctrl | View routing) - [TICK]
	3. Ctrl return parameters (Need to know) - [TICK]
	4. Viewbag (dynamically typed objects) - [TICK]
	5. Pass data to view (Strongly typed model & dynamically typed viewmodel) - [TICK]
	

#07 How to build MVC app III
	1. Testability & demo - [CHECK]
	2. Arrange | Act | Assert - [CHECK]
	3. Ctrl can be fully tested by return objects - [CHECK]
	

#08 How to Build MVC app IV
	1. Shown a few javascript libaries
		Jquery - [CHECK]
		Jquery UI - [CHECK]
		Jquery validate - [TICK]
		Modernizer - [TICK]
		

#10 Controllers I
	1. Routing Api - [TICK]
	2. Action method - [TICK]
	3. Action filters (pre\post processing method headers) - [TICK]
	4. Action parameters (Input\output) - [TICK]
	5. Action results - [TICK]
	
	
#10 Controllers II (Routing Engine)
	1. Routing engine can be used in Web Api, Web Forms, Mvc Controllers (It is not tied to Mvc) - [TICK]
	2. Gobal.asax.cs --> AplicationStart() singleton method (Base class: HttpApplication) - [TICK]
	3. RouteData (object that holds information about the Routing) - [TICK]
	

#11 Controllers III (Action parameters)
	1. How can we define new route & pass the parameters? - [TICK]
	2. Net Framework will look for the necessary from various places of URL - [TICK]
	

#12 Controllers IV (Action results)
	1. ContentResult (Content) - [TICK]
	2. HttpUnauthorizedResult (Due to method headers) - [CHECK]
	3. FileContentResult|FilePathResult|FileStreamResult (File) - [TICK]
	4. ViewResult|PartialViewResult (View|PartialView) - [TICK]
	5. EmptyResult - [TICK]
	6. RedirectToRouteResult (RedirectToRoute|RedirectToAction) - [TICK]
	7. JavaScriptResult (JavaScript) - [TICK]
	8. JsonResult (Json) - [TICK]
	9. RedirectResult (Redirect|RedirectPermanent) - [TICK]

	
#13 Controllers V (Action selectors [Method headers])
	1. Action name - [TICK]
	2. Action verbs - [TICK]
	3. Method overloading - [TICK]
	

#14 Controllers VI (Action filters)
	1. OutputCache (Cache the output of any controller) - [CHECK]
	2. Authorize (Authorize by user or roles) - [CHECK]
	3. AnitForgeryToken (Prevent Xss) - [TICK]
	4. ValidateInput (Turn off request and allow dangerous input) - [CHECK]
	5. HandleError (Renders view on unhandled exception) - [CHECK]
	6. CustomFilter (ActionFilterAttribute) - [CHECK]


#16 Views
	1. Razor + View Syntax - [TICK]
	2. Html helpers - [TICK]
	3. Layout - [TICK]
	4. Xss - [TICK]
	5. Partial views - [TICK]
	
	
#17 Views (Razor templates + scaffolding)
	1. Template + data = Generated output - [TICK]
	2. Create controller + model + view using template - [TICK]
	3. For initial development Poc, we can use inmemory data - [TICK]
	4. cshtml - C# Razor + Html5 + Js + Css3 + Modernizer - [TICK]
	   vbhtml - Vb Razor + Html5 + Js + Css3 + Modernizer - [TICK]
	   aspx\ascx - Legacy Asp.net Web applications + Html + Js + Css - [TICK]
	5. Add controller from Controllers folder - [TICK]
	6. Add models from Models folder - [TICK]
	7. Add views from Controller mothods - [TICK]
	8. Each exposed action should have a view with same name (at this moment) - [TICK]
	9. Scaffolding template is very useful - [TICK]
	
	
#18 Views (Best pratices + escaping techniques)
	1. Expressions needs to be enclosed by rounded brackets - [TICK]
	2. Virtual path signature (~) is best for relative path - [TICK]
	3. Escape razor by '@@' - [TICK]
	4. Razor html helpers as 'Auto-encoded'; avoids Xss - [TICK]
	5. Razor html helpers can also allow Xss if it is intended by 'Raw()' - [CHECK]
	

#19 Views (Escaping techniques)
	1. Use @:AnyText for escaping string literals - [TICK]
	

#20 Views (Layouts best pratices)
	1. A web application can have multiple layout can be referred from any view - [TICK]
	2. RenderBody(), RenderSection(), Url - [TICK]
	3. Viewstart file will be executed before displaying any view - [TICK]
	4. Multiple Viewstart files can be created - [TICK]
	5. Section can be anything that can be there as body does - [CHECK]
	6. Navigation (nav) option in Html5 - [TICK]
	

#21 Views (Html helpers)
	1. Html helper is the property of ViewPage base class. It can create inputs, links, forms, etc - [TICK]
	2. LabelFor, EditorFor, DisplayFor, ValidationFor, ValidationMessageFor, ValidationSummaryFor, AntiforgeryToken, ActionLink.. - [TICK]
	3. TryUpdateModelFor() will update only when validation errors are there in web forms - [CHECK]
	4. Mvc framework or routing engine knows how to parse, serialize and deserialize the information passed in via http - [TICK]
	5. Same way it couples the values from web forms, query strings, http uri,.. - [TICK]
	6. Mass assignment or over posting [TICK]
	
	
#22 Views (Partial views)
	1. This is to simplify the code & create a sub-request - [TICK]
	2. It can associate strongly-typed model - [TICK]
	3. Html.Partial, Action, ActionLink - [CHECK]
	4. Html.Action can be used to have a view with multiple model; multiple partial views can be used in a view; each partial view can hold its own model - [CHECK]
	5. Subrequest Action will not redirect to new url but it will work like ajax - [CHECK]
	6. Subsequest method needs to be implemented as 'public' but also needs to be forbidden from browser - [CHECK]
	7. Forbid by using header called, 'ChildActionOnly' - [CHECK]
	
	
#Ajax - The scripts
	1. The file, '_references.js' to enable intellisense to frequently used script libraries
	2. Jquery - core library which is manipulate\ ctrl any DOM objects in web page
	3. JqueryUI - library which helps to manipulate\ ctrl styling any DOM objects in web page
	4. JqueryValidate - Simplified version of client side validation libraries
	5. Knockout - To encourage Mvvm approach Model and view data binding
	6. Modernizr - Helps to adopt the legacy browsers; it manipulates the Html tags and descend to legacy version of Html
	7. Unobtrusive - Helps to bridge the Mvc only elements like EditorFor, LabelFor, PasswordFor in HtmlHelpers. It ctrls validation & jquery core features
	8. Minification of script libraries
	
	
#Ajax - Managing scripts
	1. Modernizr & styles may go to top of the web page as browser will be blocked when it encounters any script tags until download completes
	2. At the maximum possible, we need to try to put the scripts tags at the bottom of any web page
	3. Section tag will help us to do that
	4. Refer any scripts or stylesheets by Scripts.Render() or Styles.Render() respectively
	5. They encourage bundling
		- Minifies the dependent files wherever possible
		- Merges the files in a bundle into one which inturn helps the browser to download relatively faster. Effective oly in release mode
	6. To include the multiple files in a bundle. We can use {version} or other tags, wildcards, by relative paths,..
	7. Learn about Bootstrap
		
		
#Ajax - Helpers
	1. 