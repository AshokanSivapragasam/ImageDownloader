﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService3
{
   
    [ServiceContract(CallbackContract=typeof(IMyContractCallBack))]
    public interface IService1
    {
        [OperationContract(IsOneWay=true)]
        void   NormalFunction();

    }

    public interface IMyContractCallBack
    {
        [OperationContract(IsOneWay=true)]
        void    CallBackFunction(string str); 

    }


    
}
